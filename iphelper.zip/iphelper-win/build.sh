#!/bin/bash
# 交叉编译 Windows 版 IPHelper（macOS 上使用 mingw-w64）
# 依赖：brew install mingw-w64
set -euo pipefail
cd "$(dirname "$0")"

CXX="${CXX:-x86_64-w64-mingw32-g++}"
WINDRES="${WINDRES:-x86_64-w64-mingw32-windres}"
STRIP="${STRIP:-x86_64-w64-mingw32-strip}"
OUT="build"

mkdir -p "$OUT"

echo "==> 生成应用图标（若缺失）"
if [ ! -f "resources/app.ico" ]; then
  node tools/make_icon.js
fi

echo "==> 编译资源（图标 + 清单）"
"$WINDRES" -I src -I resources -i resources/app.rc -O coff -o "$OUT/app_res.o"

echo "==> 编译 C++（静态链接，零运行时依赖）"
"$CXX" -std=c++17 -O2 -Wall -Wextra -mwindows -static -static-libgcc -static-libstdc++ \
  -finput-charset=UTF-8 -fexec-charset=UTF-8 \
  -DWINVER=0x0601 -D_WIN32_WINNT=0x0601 -DUNICODE -D_UNICODE -DNOMINMAX -DWIN32_LEAN_AND_MEAN \
  -I src \
  src/json.cpp src/validate.cpp src/config.cpp src/ps_scripts.cpp src/win_util.cpp \
  src/network.cpp src/save_dialog.cpp src/main.cpp \
  "$OUT/app_res.o" \
  -o "$OUT/IPHelper.exe" \
  -lcomctl32 -ladvapi32 -lshell32 -luser32 -lgdi32 -lole32

"$STRIP" "$OUT/IPHelper.exe" 2>/dev/null || true

echo "==> 完成"
ls -lh "$OUT/IPHelper.exe"
