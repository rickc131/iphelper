// 纯逻辑自测（可在 macOS 上直接编译运行，不依赖 Windows）
// 覆盖：JSON 解析/序列化、IP 与掩码校验、文件名安全化、配置存档读写
#include "config.h"
#include "json.h"
#include "validate.h"

#include <cstdio>
#include <cstdlib>
#include <string>

namespace {

int g_failed = 0;

void check(bool condition, const char* label, int line) {
    if (condition) {
        std::printf("  ok    %s\n", label);
    } else {
        std::printf("  FAIL  %s  (selftest.cpp:%d)\n", label, line);
        g_failed++;
    }
}

#define CHECK(cond, label) check((cond), (label), __LINE__)

} // namespace

int main() {
    std::printf("== 校验函数 ==\n");
    CHECK(isValidIPv4("137.0.77.17"), "合法 IP 通过");
    CHECK(!isValidIPv4("999.1.1.1"), "越界 IP 拒绝");
    CHECK(!isValidIPv4("1.2.3"), "段数不足拒绝");
    CHECK(!isValidIPv4("1.2.3."), "结尾点拒绝");
    CHECK(!isValidIPv4(""), "空串拒绝");

    std::string mask;
    CHECK(prefixToMask(24, mask) && mask == "255.255.255.0", "前缀 24 → 掩码");
    CHECK(prefixToMask(0, mask) && mask == "0.0.0.0", "前缀 0 → 掩码");
    CHECK(prefixToMask(32, mask) && mask == "255.255.255.255", "前缀 32 → 掩码");
    CHECK(!prefixToMask(33, mask), "非法前缀拒绝");
    CHECK(maskToPrefix("255.255.255.0") == 24, "掩码 → 前缀");
    CHECK(maskToPrefix("255.255.0.255") == -1, "不连续掩码拒绝");

    CHECK(safeFileName("办公/网络:测试") == "办公_网络_测试", "非法字符替换");
    CHECK(safeFileName("   ") == "unnamed", "空白名回退");
    CHECK(safeFileName("CON") == "CON_", "Windows 保留名加后缀");
    CHECK(safeFileName("trailing.") == "trailing", "结尾点去除");

    std::printf("== JSON 解析（macOS 版生成格式）==\n");
    const std::string macJson = R"({
  "name" : "137",
  "interface" : "en0",
  "serviceName" : "Wi-Fi",
  "mode" : "static",
  "ip" : "137.0.77.17",
  "netmask" : "255.255.255.0",
  "gateway" : "137.0.77.1",
  "dns" : [
    "172.20.208.13"
  ]
})";
    ConfigRecord record;
    CHECK(ConfigStore::fromJson(macJson, record), "解析 macOS 配置");
    CHECK(record.name == "137" && record.ip == "137.0.77.17", "字段读取正确");
    CHECK(record.dns.size() == 1 && record.dns[0] == "172.20.208.13", "DNS 数组读取正确");
    CHECK(record.netmask == "255.255.255.0", "掩码读取正确");

    const std::string escaped =
        "{\"name\":\"\\u529e\\u516c\",\"interface\":\"以太网\",\"dns\":[]}";
    ConfigRecord escapedRecord;
    CHECK(ConfigStore::fromJson(escaped, escapedRecord), "解析 \\u 转义");
    CHECK(escapedRecord.name == "办公", "\\u 转义解码为 UTF-8");

    jsonx::Value broken;
    CHECK(!jsonx::parse("{\"a\": }", broken), "损坏 JSON 拒绝");

    std::printf("== 序列化往返 ==\n");
    ConfigRecord round = record;
    round.name = "办公室 Wi-Fi";
    round.serviceName = "Intel(R) Wi-Fi 6 AX201";
    const std::string text = ConfigStore::toJson(round);
    ConfigRecord reparsed;
    CHECK(ConfigStore::fromJson(text, reparsed), "重新解析自身输出");
    CHECK(reparsed.name == round.name && reparsed.dns == round.dns, "往返字段一致");
    CHECK(text.find("办公室 Wi-Fi") != std::string::npos, "中文原样输出（非 \\u 转义）");

    std::printf("== 配置存档（临时目录）==\n");
    const std::string base = "/tmp/iphelper-win-selftest-data";
    if (std::system(("rm -rf '" + base + "'").c_str()) != 0) {
        // 清理失败不影响测试
    }

    ConfigStore store(base);
    store.ensureDirs();
    std::string error;
    CHECK(store.list().empty(), "初始为空");
    CHECK(store.save(round, error), "保存成功");
    CHECK(!store.save(round, error), "同名拒绝覆盖");
    CHECK(store.list().size() == 1, "列表 1 项");
    CHECK(store.list()[0].record.name == round.name, "列表名称正确");

    std::string logText;
    if (FILE* log = std::fopen(store.logFile().c_str(), "rb")) {
        char buffer[512];
        const size_t count = std::fread(buffer, 1, sizeof buffer - 1, log);
        buffer[count] = '\0';
        logText = buffer;
        std::fclose(log);
    }
    CHECK(logText.find("保存配置") != std::string::npos, "日志已写入");

    CHECK(store.remove(store.list()[0], error), "删除成功");
    CHECK(store.list().empty(), "删除后为空");

    std::printf(g_failed == 0 ? "\n全部通过 ✅\n" : "\n存在失败项 ❌\n");
    return g_failed == 0 ? 0 : 1;
}
