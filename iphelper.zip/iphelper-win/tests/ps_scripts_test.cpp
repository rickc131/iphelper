// PowerShell 脚本文本生成的自测（纯逻辑，可在 macOS 上运行）
// 同时把生成的脚本写到 /tmp 供人工审阅
#include "ps_scripts.h"

#include <cstdio>
#include <fstream>
#include <string>
#include <vector>

namespace {

int g_failed = 0;

void check(bool condition, const char* label, int line) {
    if (condition) {
        std::printf("  ok    %s\n", label);
    } else {
        std::printf("  FAIL  %s  (ps_scripts_test.cpp:%d)\n", label, line);
        g_failed++;
    }
}

#define CHECK(cond, label) check((cond), (label), __LINE__)

std::string toUtf8(const std::wstring& text) {
    std::string out;
    for (size_t i = 0; i < text.size(); ++i) {
        unsigned codePoint = static_cast<unsigned short>(text[i]);
        if (codePoint >= 0xD800 && codePoint <= 0xDBFF && i + 1 < text.size()) {
            const unsigned low = static_cast<unsigned short>(text[i + 1]);
            if (low >= 0xDC00 && low <= 0xDFFF) {
                codePoint = 0x10000u + ((codePoint - 0xD800u) << 10) + (low - 0xDC00u);
                ++i;
            }
        }
        if (codePoint <= 0x7F) {
            out.push_back(static_cast<char>(codePoint));
        } else if (codePoint <= 0x7FF) {
            out.push_back(static_cast<char>(0xC0 | (codePoint >> 6)));
            out.push_back(static_cast<char>(0x80 | (codePoint & 0x3F)));
        } else if (codePoint <= 0xFFFF) {
            out.push_back(static_cast<char>(0xE0 | (codePoint >> 12)));
            out.push_back(static_cast<char>(0x80 | ((codePoint >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (codePoint & 0x3F)));
        } else {
            out.push_back(static_cast<char>(0xF0 | (codePoint >> 18)));
            out.push_back(static_cast<char>(0x80 | ((codePoint >> 12) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | ((codePoint >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (codePoint & 0x3F)));
        }
    }
    return out;
}

bool writeText(const std::string& path, const std::wstring& text) {
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) return false;
    const std::string utf8 = toUtf8(text);
    out.write(utf8.data(), static_cast<std::streamsize>(utf8.size()));
    return out.good();
}

bool contains(const std::wstring& text, const std::wstring& needle) {
    return text.find(needle) != std::wstring::npos;
}

} // namespace

int main() {
    const std::wstring statusFile = L"C:\\Users\\tester\\AppData\\Local\\Temp\\iph1234.txt";
    const std::wstring adapter = L"John's Wi-Fi";   // 含单引号，验证转义

    std::vector<std::wstring> commands;
    commands.push_back(L"interface ipv4 set address name=\"" + adapter + L"\" static 10.0.0.5 255.255.255.0 10.0.0.1");
    commands.push_back(L"interface ipv4 set dns name=\"" + adapter + L"\" static 8.8.8.8 primary");
    commands.push_back(L"interface ipv4 add dns name=\"" + adapter + L"\" 1.1.1.1 index=2");

    const std::wstring worker = buildNetshWorkerScript(commands, statusFile);
    // 用假载荷模拟 base64 编码后的 worker（base64 字母表内字符）
    const std::string payload(2048, 'Q');
    const std::wstring launcher = buildElevationLauncherScript(payload, statusFile);

    std::printf("== 转义 ==\n");
    CHECK(escapePsSingleQuoted(L"John's") == L"John''s", "单引号转义为双写");
    CHECK(contains(worker, L"John''s Wi-Fi"), "命令中的单引号已转义");

    std::printf("== 提权执行脚本（worker）==\n");
    CHECK(contains(worker, L"Join-Path $env:SystemRoot 'System32\\netsh.exe'"), "netsh 使用绝对路径");
    CHECK(contains(worker, L"$cmds = @("), "命令数组以 @( 起始");
    CHECK(worker.find(L"',\r\n") == std::wstring::npos, "无尾随逗号（避免语法风险）");
    CHECK(contains(worker, L"& $netsh $c"), "逐条执行 netsh");
    CHECK(contains(worker, L"if ($null -eq $code) { $code = 1 }"), "$LASTEXITCODE 为空时兜底为失败");
    CHECK(contains(worker, L"'OK' | Set-Content"), "成功后写 OK 状态文件");
    CHECK(contains(worker, L"exit 0"), "成功退出码 0");
    CHECK(contains(worker, L"interface ipv4 set address name=\"John''s Wi-Fi\" static 10.0.0.5 255.255.255.0 10.0.0.1"),
          "静态地址命令内容完整");
    CHECK(contains(worker, L"add dns name=\"John''s Wi-Fi\" 1.1.1.1 index=2"), "第二 DNS 使用 index=2");

    std::printf("== UAC 启动器（launcher）==\n");
    CHECK(contains(launcher, L"-Verb RunAs"), "使用 RunAs 触发 UAC");
    CHECK(contains(launcher, L"WindowsPowerShell\\v1.0\\powershell.exe"), "提权子进程使用绝对路径");
    CHECK(contains(launcher, L"'-EncodedCommand'"), "以 EncodedCommand 传递 worker");
    CHECK(contains(launcher, L"Start-Process"), "通过 Start-Process 提权");
    CHECK(contains(launcher, L"Set-Content -LiteralPath 'C:\\Users\\tester"), "异常信息写入状态文件");
    CHECK(contains(launcher, std::wstring(64, L'Q')), "worker 载荷已嵌入 launcher");
    CHECK(contains(launcher, L"exit 3"), "取消/异常时以退出码 3 返回");

    writeText("/tmp/iphelper-ps-worker.ps1", worker);
    writeText("/tmp/iphelper-ps-launcher.ps1", launcher);
    const std::string launcherPreview = toUtf8(launcher).substr(0, 300);
    std::printf("\n生成脚本已写入：\n  /tmp/iphelper-ps-worker.ps1\n  /tmp/iphelper-ps-launcher.ps1\n(launcher 前 300 字符)\n%s\n",
                launcherPreview.c_str());

    std::printf(g_failed == 0 ? "\n全部通过 ✅\n" : "\n存在失败项 ❌\n");
    return g_failed == 0 ? 0 : 1;
}
