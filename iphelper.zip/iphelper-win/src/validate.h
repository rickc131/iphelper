#pragma once

#include <string>

/// 严格校验 IPv4（点分十进制，0-255，四段）
bool isValidIPv4(const std::string& value);

/// 前缀长度 → 点分十进制掩码（0-32）；失败返回 false
bool prefixToMask(int prefix, std::string& mask);

/// 点分十进制掩码 → 前缀长度；非法或掩码不连续返回 -1
int maskToPrefix(const std::string& mask);

/// 与 macOS 版等价的文件名安全化（过滤非法字符、保留名、首尾空白/点）
std::string safeFileName(const std::string& name);
