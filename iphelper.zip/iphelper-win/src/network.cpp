#include "network.h"

#include "ps_scripts.h"
#include "validate.h"
#include "win_util.h"

#include <algorithm>
#include <cstdlib>
#include <string>
#include <vector>

namespace {

/// 结果文件里是否记录了“用户取消授权”
bool looksCanceled(const std::wstring& message) {
    static const wchar_t* kPatterns[] = {L"cancel", L"取消", L"1223"};
    for (const wchar_t* pattern : kPatterns) {
        if (message.find(pattern) != std::wstring::npos) return true;
    }
    return false;
}

/// 把 netsh 命令列表打包成自提权脚本，并执行
bool runElevatedNetsh(const std::vector<std::wstring>& commands, std::wstring& error, bool& canceled) {
    canceled = false;

    const std::wstring resultFile = makeTempFilePath();
    deleteFileIfExists(resultFile);

    // 提权后执行的脚本 + 非提权启动器（会弹 UAC），脚本内容由可移植模块生成
    const std::wstring worker = buildNetshWorkerScript(commands, resultFile);
    const std::string workerBase64 = base64Encode(utf16LeBytes(worker));
    const std::wstring launcher = buildElevationLauncherScript(workerBase64, resultFile);

    std::string output;
    DWORD exitCode = 0;
    if (!runPowerShell(launcher, INFINITE, output, exitCode)) {
        error = L"无法启动 PowerShell，请确认系统可用（Windows 10/11 自带）。";
        deleteFileIfExists(resultFile);
        return false;
    }

    // 判定结果以提权脚本写的状态文件为准（-Verb RunAs 下 ExitCode 未必可靠）
    std::string detail;
    const bool hasDetail = readFileBytes(resultFile, detail);
    deleteFileIfExists(resultFile);

    std::wstring status;
    if (hasDetail) {
        // 去掉 PowerShell 写文件时可能带上的 UTF-8 BOM
        if (detail.size() >= 3 && static_cast<unsigned char>(detail[0]) == 0xEF &&
            static_cast<unsigned char>(detail[1]) == 0xBB && static_cast<unsigned char>(detail[2]) == 0xBF) {
            detail.erase(0, 3);
        }
        status = utf8ToWide(detail);
        while (!status.empty() && (status.back() == L'\r' || status.back() == L'\n' || status.back() == L' ')) {
            status.pop_back();
        }
    }

    if (status == L"OK") return true;
    if (status.empty() && exitCode == 0 && !hasDetail) return true;

    if (!status.empty()) {
        error = status;
    } else if (!output.empty()) {
        error = utf8ToWide(output);
    } else {
        error = L"操作失败（退出码 " + std::to_wstring(exitCode) + L"）";
    }

    if (looksCanceled(error)) {
        canceled = true;
        error.clear();
    }
    return false;
}

} // namespace

std::vector<Adapter> listAdapters(std::wstring* error) {
    std::vector<Adapter> adapters;

    std::wstring script;
    script += L"[Console]::OutputEncoding = [Text.Encoding]::UTF8\r\n";
    script += L"$ErrorActionPreference = 'SilentlyContinue'\r\n";
    script += L"$items = Get-NetAdapter -Physical | Where-Object { $_.Status -ne 'Not Present' } | Sort-Object ifIndex\r\n";
    script += L"if (-not $items) { $items = Get-NetAdapter | Where-Object { $_.Status -ne 'Not Present' } | Sort-Object ifIndex }\r\n";
    script += L"foreach ($a in $items) {\r\n";
    script += L"  $addr = Get-NetIPAddress -InterfaceAlias $a.Name -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.PrefixOrigin -ne 'WellKnown' } | Select-Object -First 1\r\n";
    script += L"  $ip = ''\r\n";
    script += L"  if ($addr) { $ip = $addr.IPAddress }\r\n";
    script += L"  Write-Output ('{0}|{1}|{2}' -f $a.Name, $a.InterfaceDescription, $ip)\r\n";
    script += L"}\r\n";

    std::string output;
    DWORD exitCode = 0;
    if (!runPowerShell(script, 30000, output, exitCode) || exitCode != 0) {
        if (error) *error = L"读取网卡列表失败（PowerShell 不可用？）";
        return adapters;
    }

    // 按行解析 name|description|ipv4
    size_t start = 0;
    while (start <= output.size()) {
        size_t end = output.find('\n', start);
        if (end == std::string::npos) end = output.size();
        std::string line = output.substr(start, end - start);
        start = end + 1;

        while (!line.empty() && (line.back() == '\r' || line.back() == ' ')) line.pop_back();
        if (line.empty()) continue;

        const size_t first = line.find('|');
        if (first == std::string::npos) continue;
        const size_t second = line.find('|', first + 1);
        if (second == std::string::npos) continue;

        Adapter adapter;
        adapter.name = utf8ToWide(line.substr(0, first));
        adapter.description = utf8ToWide(line.substr(first + 1, second - first - 1));
        adapter.ipv4 = utf8ToWide(line.substr(second + 1));
        if (!adapter.name.empty()) adapters.push_back(adapter);

        if (end == output.size()) break;
    }
    return adapters;
}

CurrentConfig readCurrentConfig(const std::wstring& adapterName) {
    CurrentConfig config;
    config.mode = L"dhcp";

    std::wstring script;
    script += L"[Console]::OutputEncoding = [Text.Encoding]::UTF8\r\n";
    script += L"$ErrorActionPreference = 'SilentlyContinue'\r\n";
    script += L"$name = '" + escapePsSingleQuoted(adapterName) + L"'\r\n";
    script += L"$addr = Get-NetIPAddress -InterfaceAlias $name -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.PrefixOrigin -ne 'WellKnown' } | Select-Object -First 1\r\n";
    script += L"$ifc = Get-NetIPInterface -InterfaceAlias $name -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -First 1\r\n";
    script += L"$cfg = Get-NetIPConfiguration -InterfaceAlias $name -ErrorAction SilentlyContinue\r\n";
    script += L"$gw = ''\r\n";
    script += L"if ($cfg -and $cfg.IPv4DefaultGateway) { $gw = $cfg.IPv4DefaultGateway.NextHop }\r\n";
    script += L"$dns = ''\r\n";
    script += L"if ($cfg -and $cfg.DNSServer) { $dns = (($cfg.DNSServer | Where-Object { $_.AddressFamily -eq 2 } | ForEach-Object { $_.Address }) -join ',') }\r\n";
    script += L"$ip = ''\r\n";
    script += L"$prefix = ''\r\n";
    script += L"if ($addr) { $ip = $addr.IPAddress; $prefix = $addr.PrefixLength }\r\n";
    script += L"$mode = 'static'\r\n";
    script += L"if (-not $ifc -or $ifc.Dhcp -eq 'Enabled') { $mode = 'dhcp' }\r\n";
    script += L"Write-Output ('{0}|{1}|{2}|{3}|{4}' -f $mode, $ip, $prefix, $gw, $dns)\r\n";

    std::string output;
    DWORD exitCode = 0;
    if (!runPowerShell(script, 30000, output, exitCode)) return config;

    size_t start = 0;
    while (start <= output.size()) {
        size_t end = output.find('\n', start);
        if (end == std::string::npos) end = output.size();
        std::string line = output.substr(start, end - start);
        start = end + 1;

        while (!line.empty() && (line.back() == '\r' || line.back() == ' ')) line.pop_back();
        if (line.empty()) continue;

        // 拆成 5 段
        std::vector<std::string> fields;
        size_t pos = 0;
        while (true) {
            const size_t bar = line.find('|', pos);
            fields.push_back(line.substr(pos, bar == std::string::npos ? std::string::npos : bar - pos));
            if (bar == std::string::npos) break;
            pos = bar + 1;
        }
        if (fields.size() < 5) continue;

        config.mode = fields[0] == "dhcp" ? L"dhcp" : L"static";
        config.ip = utf8ToWide(fields[1]);
        config.netmask.clear();
        if (!fields[2].empty()) {
            std::string mask;
            if (prefixToMask(std::atoi(fields[2].c_str()), mask)) config.netmask = utf8ToWide(mask);
        }
        config.gateway = utf8ToWide(fields[3]);
        config.dns.clear();
        if (!fields[4].empty()) {
            size_t dnsPos = 0;
            while (dnsPos <= fields[4].size()) {
                const size_t comma = fields[4].find(',', dnsPos);
                const std::string item = fields[4].substr(dnsPos, comma == std::string::npos ? std::string::npos : comma - dnsPos);
                if (!item.empty()) config.dns.push_back(utf8ToWide(item));
                if (comma == std::string::npos) break;
                dnsPos = comma + 1;
            }
        }
        break;
    }
    return config;
}

bool applyConfig(const ConfigRecord& record, std::wstring& error, bool& canceled) {
    canceled = false;

    if (record.interfaceName.empty()) {
        error = L"配置缺少网卡信息，请在菜单中重新保存该配置。";
        return false;
    }
    if (record.mode == "dhcp") {
        return applyDhcp(record.interfaceName, error, canceled);
    }

    const std::wstring adapter = utf8ToWide(record.interfaceName);
    if (adapter.find(L'"') != std::wstring::npos) {
        error = L"网卡名称包含非法字符，无法执行。";
        return false;
    }
    if (!isValidIPv4(record.ip)) {
        error = L"配置中的 IP 地址无效：" + utf8ToWide(record.ip);
        return false;
    }
    if (!isValidIPv4(record.netmask)) {
        error = L"配置中的子网掩码无效：" + utf8ToWide(record.netmask);
        return false;
    }

    // 网关为空时保留该网卡当前网关（与 macOS 行为一致）
    std::wstring gateway = utf8ToWide(record.gateway);
    if (gateway.empty()) gateway = readCurrentConfig(adapter).gateway;
    if (gateway.empty()) {
        gateway = L"none";
    } else if (!isValidIPv4(wideToUtf8(gateway))) {
        error = L"配置中的网关地址无效：" + gateway;
        return false;
    }

    std::vector<std::wstring> dns;
    for (const auto& server : record.dns) {
        if (!isValidIPv4(server)) {
            error = L"配置中的 DNS 地址无效：" + utf8ToWide(server);
            return false;
        }
        dns.push_back(utf8ToWide(server));
    }

    std::vector<std::wstring> commands;
    commands.push_back(L"interface ipv4 set address name=\"" + adapter + L"\" static " +
                       utf8ToWide(record.ip) + L" " + utf8ToWide(record.netmask) + L" " + gateway);
    if (!dns.empty()) {
        commands.push_back(L"interface ipv4 set dns name=\"" + adapter + L"\" static " + dns[0] + L" primary");
        for (size_t i = 1; i < dns.size(); ++i) {
            commands.push_back(L"interface ipv4 add dns name=\"" + adapter + L"\" " +
                               dns[i] + L" index=" + std::to_wstring(i + 1));
        }
    } else {
        commands.push_back(L"interface ipv4 set dns name=\"" + adapter + L"\" dhcp");
    }

    return runElevatedNetsh(commands, error, canceled);
}

bool applyDhcp(const std::string& adapterNameUtf8, std::wstring& error, bool& canceled) {
    canceled = false;

    const std::wstring adapter = utf8ToWide(adapterNameUtf8);
    if (adapter.empty()) {
        error = L"未指定网卡。";
        return false;
    }
    if (adapter.find(L'"') != std::wstring::npos) {
        error = L"网卡名称包含非法字符，无法执行。";
        return false;
    }

    std::vector<std::wstring> commands;
    commands.push_back(L"interface ipv4 set address name=\"" + adapter + L"\" dhcp");
    commands.push_back(L"interface ipv4 set dns name=\"" + adapter + L"\" dhcp");
    return runElevatedNetsh(commands, error, canceled);
}
