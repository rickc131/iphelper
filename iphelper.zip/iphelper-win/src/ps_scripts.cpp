#include "ps_scripts.h"

std::wstring escapePsSingleQuoted(const std::wstring& text) {
    std::wstring out;
    out.reserve(text.size() + 2);
    for (const wchar_t c : text) {
        if (c == L'\'') out += L"''";
        else out.push_back(c);
    }
    return out;
}

std::wstring buildNetshWorkerScript(const std::vector<std::wstring>& netshCommandLines,
                                    const std::wstring& statusFile) {
    const std::wstring status = escapePsSingleQuoted(statusFile);

    std::wstring script;
    script += L"$ErrorActionPreference = 'Continue'\r\n";
    script += L"$netsh = Join-Path $env:SystemRoot 'System32\\netsh.exe'\r\n";
    script += L"$log = New-Object System.Collections.ArrayList\r\n";
    script += L"$cmds = @(\r\n";
    for (const auto& command : netshCommandLines) {
        script += L"'" + escapePsSingleQuoted(command) + L"'\r\n"; // 每行一个元素，避免尾随逗号
    }
    script += L")\r\n";
    script += L"foreach ($c in $cmds) {\r\n";
    script += L"  $out = & $netsh $c 2>&1\r\n";
    script += L"  $code = $LASTEXITCODE\r\n";
    script += L"  if ($null -eq $code) { $code = 1 }\r\n";
    script += L"  foreach ($line in $out) { [void]$log.Add(($line | Out-String).Trim()) }\r\n";
    script += L"  if ($code -ne 0) {\r\n";
    script += L"    ($log -join [Environment]::NewLine) | Set-Content -LiteralPath '" + status + L"' -Encoding UTF8\r\n";
    script += L"    exit $code\r\n";
    script += L"  }\r\n";
    script += L"}\r\n";
    script += L"'OK' | Set-Content -LiteralPath '" + status + L"' -Encoding UTF8\r\n";
    script += L"exit 0\r\n";
    return script;
}

std::wstring buildElevationLauncherScript(const std::string& workerBase64,
                                          const std::wstring& statusFile) {
    // base64 只含 A-Za-z0-9+/=，放进 PowerShell 单引号中是安全的
    const std::wstring worker(workerBase64.begin(), workerBase64.end());
    const std::wstring status = escapePsSingleQuoted(statusFile);

    std::wstring script;
    script += L"$ErrorActionPreference = 'Stop'\r\n";
    script += L"try {\r\n";
    script += L"  $exe = Join-Path $env:SystemRoot 'System32\\WindowsPowerShell\\v1.0\\powershell.exe'\r\n";
    script += L"  $p = Start-Process -FilePath $exe -ArgumentList @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-EncodedCommand','";
    script += worker;
    script += L"') -Verb RunAs -Wait -PassThru\r\n";
    script += L"  $code = 0\r\n";
    script += L"  if ($p -and $null -ne $p.ExitCode) { $code = $p.ExitCode }\r\n";
    script += L"  exit $code\r\n";
    script += L"} catch {\r\n";
    script += L"  ($_ | Out-String) | Set-Content -LiteralPath '" + status + L"' -Encoding UTF8\r\n";
    script += L"  exit 3\r\n";
    script += L"}\r\n";
    return script;
}
