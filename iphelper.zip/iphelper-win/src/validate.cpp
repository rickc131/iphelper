#include "validate.h"

#include <cstdio>
#include <cstdlib>

bool isValidIPv4(const std::string& value) {
    if (value.empty()) return false;
    int parts = 0;
    size_t i = 0;
    while (i < value.size()) {
        int number = 0;
        int digits = 0;
        while (i < value.size() && value[i] >= '0' && value[i] <= '9') {
            number = number * 10 + (value[i] - '0');
            if (++digits > 3) return false;
            i++;
        }
        if (digits == 0) return false;
        if (number > 255) return false;
        parts++;
        if (i < value.size()) {
            if (value[i] != '.') return false;
            i++;
            if (i == value.size()) return false; // 不能以点结尾
        }
    }
    return parts == 4;
}

bool prefixToMask(int prefix, std::string& mask) {
    if (prefix < 0 || prefix > 32) return false;
    const unsigned bits = prefix == 0 ? 0u : (0xFFFFFFFFu << (32 - prefix));
    char buf[32];
    std::snprintf(buf, sizeof buf, "%u.%u.%u.%u",
                  (bits >> 24) & 0xFFu, (bits >> 16) & 0xFFu, (bits >> 8) & 0xFFu, bits & 0xFFu);
    mask = buf;
    return true;
}

int maskToPrefix(const std::string& mask) {
    if (!isValidIPv4(mask)) return -1;

    unsigned bits = 0;
    int shift = 24;
    size_t start = 0;
    for (int part = 0; part < 4; ++part) {
        const size_t dot = mask.find('.', start);
        const size_t end = (dot == std::string::npos) ? mask.size() : dot;
        bits |= static_cast<unsigned>(std::atoi(mask.substr(start, end - start).c_str())) << shift;
        shift -= 8;
        if (dot == std::string::npos) break;
        start = dot + 1;
    }

    int prefix = 0;
    bool zeroSeen = false;
    for (int bit = 31; bit >= 0; --bit) {
        const bool set = ((bits >> bit) & 1u) != 0;
        if (set && zeroSeen) return -1; // 掩码位不连续
        if (set) prefix++;
        else zeroSeen = true;
    }
    return prefix;
}

std::string safeFileName(const std::string& name) {
    std::string out;
    for (const unsigned char c : name) {
        if (c < 0x20) {
            out += '_';
            continue;
        }
        switch (c) {
            case '<': case '>': case ':': case '"':
            case '/': case '\\': case '|': case '?': case '*':
                out += '_';
                break;
            default:
                out.push_back(static_cast<char>(c));
        }
    }

    // 去掉首尾空白与结尾的点（Windows 文件名限制）
    size_t begin = 0;
    size_t end = out.size();
    while (begin < end && (out[begin] == ' ' || out[begin] == '\t')) begin++;
    while (end > begin && (out[end - 1] == ' ' || out[end - 1] == '\t' || out[end - 1] == '.')) end--;
    out = out.substr(begin, end - begin);

    if (out.empty()) return "unnamed";

    static const char* kReserved[] = {
        "CON", "PRN", "AUX", "NUL",
        "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
        "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9",
    };
    for (const char* reserved : kReserved) {
        if (out == reserved) {
            out += "_";
            break;
        }
    }
    return out;
}
