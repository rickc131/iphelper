#pragma once

#include <string>
#include <vector>

#include "config.h"

/// 网卡信息（name 为 netsh / Get-NetAdapter 使用的别名）
struct Adapter {
    std::wstring name;
    std::wstring description;
    std::wstring ipv4;
};

struct CurrentConfig {
    std::wstring mode;       // static / dhcp
    std::wstring ip;
    std::wstring netmask;
    std::wstring gateway;
    std::vector<std::wstring> dns;
};

/// 物理网卡列表（含各自当前 IPv4，便于挑选“正在使用”的网卡）
std::vector<Adapter> listAdapters(std::wstring* error);

/// 读取指定网卡的当前配置（DHCP 状态 / IP / 掩码 / 网关 / DNS）
CurrentConfig readCurrentConfig(const std::wstring& adapterName);

/// 应用配置：mode=dhcp 时切换为 DHCP，否则按静态 IP + DNS 设置
/// canceled 为 true 表示用户在 UAC 授权框中点了取消（应静默处理）
bool applyConfig(const ConfigRecord& record, std::wstring& error, bool& canceled);

/// 恢复 DHCP
bool applyDhcp(const std::string& adapterNameUtf8, std::wstring& error, bool& canceled);
