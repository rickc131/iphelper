#include "save_dialog.h"

#include "config.h"
#include "network.h"
#include "validate.h"
#include "win_util.h"

#include <string>
#include <vector>

#include <windows.h>

namespace {

const wchar_t* kClassName = L"IPHelperSaveDialogClass";

const int kComboId = 1001;
const int kInfoId = 1002;
const int kEditId = 1003;

struct DialogState {
    HWND hwnd = nullptr;
    HWND combo = nullptr;
    HWND info = nullptr;
    HWND edit = nullptr;
    HFONT font = nullptr;
    WNDPROC editProc = nullptr;
    std::vector<Adapter> adapters;
    CurrentConfig current;
    bool hasCurrent = false;
    bool saved = false;
    const ConfigStore* store = nullptr;
};

int screenDpi() {
    HDC dc = GetDC(nullptr);
    const int dpi = dc ? GetDeviceCaps(dc, LOGPIXELSX) : 96;
    if (dc) ReleaseDC(nullptr, dc);
    return dpi > 0 ? dpi : 96;
}

int px(int value, int dpi) { return MulDiv(value, dpi, 96); }

void setFont(HWND control, HFONT font) {
    SendMessageW(control, WM_SETFONT, reinterpret_cast<WPARAM>(font), TRUE);
}

std::wstring describe(const CurrentConfig& config) {
    std::wstring dns;
    if (config.dns.empty()) {
        dns = L"自动";
    } else {
        for (size_t i = 0; i < config.dns.size(); ++i) {
            if (i > 0) dns += L", ";
            dns += config.dns[i];
        }
    }

    std::wstring text;
    text += L"模式: " + std::wstring(config.mode == L"dhcp" ? L"DHCP" : L"静态") + L"\r\n";
    text += L"IP: " + (config.ip.empty() ? L"—" : config.ip) + L" / " +
            (config.netmask.empty() ? L"—" : config.netmask) + L"\r\n";
    text += L"网关: " + (config.gateway.empty() ? L"—" : config.gateway) + L"\r\n";
    text += L"DNS: " + dns;
    return text;
}

void refreshInfo(DialogState* state) {
    if (!state->combo || !state->info) return;

    const int index = static_cast<int>(SendMessageW(state->combo, CB_GETCURSEL, 0, 0));
    if (index < 0 || index >= static_cast<int>(state->adapters.size())) return;

    SetWindowTextW(state->info, L"读取中…");
    state->hasCurrent = false;

    const HCURSOR previous = SetCursor(LoadCursorW(nullptr, IDC_WAIT));
    state->current = readCurrentConfig(state->adapters[static_cast<size_t>(index)].name);
    state->hasCurrent = true;
    SetCursor(previous);

    SetWindowTextW(state->info, describe(state->current).c_str());
}

void warn(HWND owner, const std::wstring& message) {
    MessageBoxW(owner, message.c_str(), L"IPHelper", MB_OK | MB_ICONWARNING);
}

void doSave(DialogState* state) {
    wchar_t nameBuffer[256] = {0};
    GetWindowTextW(state->edit, nameBuffer, 255);
    std::wstring name = nameBuffer;
    while (!name.empty() && (name.front() == L' ' || name.front() == L'\t')) name.erase(name.begin());
    while (!name.empty() && (name.back() == L' ' || name.back() == L'\t')) name.pop_back();

    if (name.empty()) {
        warn(state->hwnd, L"请填写配置名称");
        SetFocus(state->edit);
        return;
    }
    if (!state->hasCurrent) {
        warn(state->hwnd, L"正在读取当前网络信息，请稍候重试");
        return;
    }

    const int index = static_cast<int>(SendMessageW(state->combo, CB_GETCURSEL, 0, 0));
    if (index < 0 || index >= static_cast<int>(state->adapters.size())) return;

    ConfigRecord record;
    record.name = wideToUtf8(name);
    record.interfaceName = wideToUtf8(state->adapters[static_cast<size_t>(index)].name);
    record.serviceName = wideToUtf8(state->adapters[static_cast<size_t>(index)].description);
    record.mode = (state->current.mode == L"dhcp") ? "dhcp" : "static";
    record.ip = wideToUtf8(state->current.ip);
    record.netmask = wideToUtf8(state->current.netmask);
    record.gateway = wideToUtf8(state->current.gateway);
    for (const auto& server : state->current.dns) record.dns.push_back(wideToUtf8(server));

    if (!record.ip.empty() && !isValidIPv4(record.ip)) {
        warn(state->hwnd, L"IP 地址格式无效：" + state->current.ip);
        return;
    }
    if (!record.netmask.empty() && !isValidIPv4(record.netmask)) {
        warn(state->hwnd, L"子网掩码格式无效：" + state->current.netmask);
        return;
    }
    if (!record.gateway.empty() && !isValidIPv4(record.gateway)) {
        warn(state->hwnd, L"网关地址格式无效：" + state->current.gateway);
        return;
    }
    for (const auto& server : state->current.dns) {
        if (!isValidIPv4(wideToUtf8(server))) {
            warn(state->hwnd, L"DNS 地址格式无效：" + server);
            return;
        }
    }

    std::string error;
    if (!state->store->save(record, error)) {
        warn(state->hwnd, utf8ToWide(error));
        return;
    }
    state->saved = true;
    DestroyWindow(state->hwnd);
}

LRESULT CALLBACK editProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    auto* state = reinterpret_cast<DialogState*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (msg == WM_KEYDOWN && wParam == VK_RETURN) {
        if (state) PostMessageW(state->hwnd, WM_COMMAND, MAKEWPARAM(IDOK, BN_CLICKED), 0);
        return 0;
    }
    if (msg == WM_CHAR && (wParam == L'\r' || wParam == L'\n')) return 0;
    if (state && state->editProc) {
        return CallWindowProcW(state->editProc, hwnd, msg, wParam, lParam);
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

void buildControls(DialogState* state) {
    const int dpi = screenDpi();
    const HINSTANCE instance = reinterpret_cast<HINSTANCE>(GetWindowLongPtrW(state->hwnd, GWLP_HINSTANCE));

    // 与系统一致的界面字体
    NONCLIENTMETRICSW metrics{};
    metrics.cbSize = sizeof(metrics);
    if (SystemParametersInfoW(SPI_GETNONCLIENTMETRICS, sizeof(metrics), &metrics, 0)) {
        state->font = CreateFontIndirectW(&metrics.lfMessageFont);
    }
    if (!state->font) state->font = static_cast<HFONT>(GetStockObject(DEFAULT_GUI_FONT));

    auto create = [&](const wchar_t* cls, const wchar_t* text, DWORD style, int x, int y, int w, int h,
                      int id, DWORD exStyle = 0) {
        HWND control = CreateWindowExW(exStyle, cls, text, WS_CHILD | WS_VISIBLE | style,
                                       px(x, dpi), px(y, dpi), px(w, dpi), px(h, dpi),
                                       state->hwnd, reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),
                                       instance, nullptr);
        if (control) setFont(control, state->font);
        return control;
    };

    create(L"STATIC", L"网卡", 0, 16, 20, 40, 18, -1);
    state->combo = create(L"COMBOBOX", L"", WS_TABSTOP | CBS_DROPDOWNLIST | WS_VSCROLL,
                          60, 16, 348, 200, kComboId);
    state->info = create(L"STATIC", L"读取中…", SS_LEFT, 16, 54, 392, 74, kInfoId);
    create(L"STATIC", L"名称", 0, 16, 142, 40, 18, -1);
    state->edit = create(L"EDIT", L"", WS_TABSTOP | ES_AUTOHSCROLL,
                         60, 138, 348, 24, kEditId, WS_EX_CLIENTEDGE);
    create(L"STATIC", L"保存到 configs 存档目录；同名不会覆盖", 0, 16, 170, 392, 16, -1);
    create(L"BUTTON", L"保存", WS_TABSTOP | BS_DEFPUSHBUTTON, 244, 198, 80, 26, IDOK);
    create(L"BUTTON", L"取消", WS_TABSTOP | BS_PUSHBUTTON, 332, 198, 80, 26, IDCANCEL);

    if (state->edit) {
        SetWindowLongPtrW(state->edit, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(state));
        state->editProc = reinterpret_cast<WNDPROC>(
            SetWindowLongPtrW(state->edit, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(editProc)));
    }

    // 填充网卡列表，并优先选中“正在使用”的那块
    state->adapters = listAdapters(nullptr);
    if (!state->combo || !state->info) return; // 控件创建异常时安全退出

    int activeIndex = 0;
    bool activeFound = false;
    for (size_t i = 0; i < state->adapters.size(); ++i) {
        const std::wstring label = state->adapters[i].name + L" — " + state->adapters[i].description;
        SendMessageW(state->combo, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(label.c_str()));
        if (!activeFound && !state->adapters[i].ipv4.empty()) {
            activeIndex = static_cast<int>(i);
            activeFound = true;
        }
    }
    if (!state->adapters.empty()) {
        SendMessageW(state->combo, CB_SETCURSEL, static_cast<WPARAM>(activeIndex), 0);
        refreshInfo(state);
    } else {
        SetWindowTextW(state->info, L"未检测到可用网卡");
    }
}

LRESULT CALLBACK dialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    auto* state = reinterpret_cast<DialogState*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));

    switch (msg) {
        case WM_CREATE: {
            auto* create = reinterpret_cast<CREATESTRUCTW*>(lParam);
            state = static_cast<DialogState*>(create->lpCreateParams);
            state->hwnd = hwnd;
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(state));
            buildControls(state);
            return 0;
        }
        case WM_COMMAND: {
            if (!state) break;
            const int id = LOWORD(wParam);
            const int code = HIWORD(wParam);
            if (id == kComboId && code == CBN_SELCHANGE) {
                refreshInfo(state);
                return 0;
            }
            if (id == IDOK) {
                doSave(state);
                return 0;
            }
            if (id == IDCANCEL) {
                DestroyWindow(hwnd);
                return 0;
            }
            break;
        }
        case WM_KEYDOWN:
            if (wParam == VK_ESCAPE) {
                DestroyWindow(hwnd);
                return 0;
            }
            break;
        case WM_CLOSE:
            DestroyWindow(hwnd);
            return 0;
        case WM_NCDESTROY:
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, 0);
            break;
        default:
            break;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

} // namespace

bool showSaveDialog(HWND owner, const ConfigStore& store) {
    static bool classRegistered = false;
    if (!classRegistered) {
        WNDCLASSEXW wc{};
        wc.cbSize = sizeof(wc);
        wc.lpfnWndProc = dialogProc;
        wc.hInstance = GetModuleHandleW(nullptr);
        wc.lpszClassName = kClassName;
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_BTNFACE + 1);
        wc.style = CS_HREDRAW | CS_VREDRAW;
        if (!RegisterClassExW(&wc)) return false;
        classRegistered = true;
    }

    const int dpi = screenDpi();
    RECT rect{0, 0, px(424, dpi), px(240, dpi)};
    AdjustWindowRectEx(&rect, WS_CAPTION | WS_SYSMENU, FALSE, WS_EX_DLGMODALFRAME);

    DialogState state;
    state.store = &store;

    HWND hwnd = CreateWindowExW(WS_EX_DLGMODALFRAME, kClassName, L"保存当前配置",
                                WS_CAPTION | WS_SYSMENU | WS_POPUP,
                                0, 0, rect.right - rect.left, rect.bottom - rect.top,
                                owner, nullptr, GetModuleHandleW(nullptr), &state);
    if (!hwnd) return false;

    RECT windowRect{};
    GetWindowRect(hwnd, &windowRect);
    RECT workArea{};
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &workArea, 0);
    const int width = windowRect.right - windowRect.left;
    const int height = windowRect.bottom - windowRect.top;
    SetWindowPos(hwnd, nullptr,
                 workArea.left + ((workArea.right - workArea.left) - width) / 2,
                 workArea.top + ((workArea.bottom - workArea.top) - height) / 2,
                 0, 0, SWP_NOSIZE | SWP_NOZORDER);

    if (owner) EnableWindow(owner, FALSE);
    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);
    SetForegroundWindow(hwnd);
    if (state.edit) SetFocus(state.edit);

    MSG msg;
    while (IsWindow(hwnd) && GetMessageW(&msg, nullptr, 0, 0) > 0) {
        if (msg.hwnd == hwnd || IsChild(hwnd, msg.hwnd)) {
            if (IsDialogMessageW(hwnd, &msg)) continue;
        }
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    if (owner) EnableWindow(owner, TRUE);
    if (state.font) DeleteObject(state.font);
    return state.saved;
}
