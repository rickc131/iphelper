#pragma once

#include <string>
#include <vector>

/// 与 macOS 版完全一致的配置字段（interface = 网卡名，serviceName = 网卡描述）
struct ConfigRecord {
    std::string name;
    std::string interfaceName;   // Windows: 网卡别名，如 "以太网" / "Wi-Fi"
    std::string serviceName;     // Windows: 网卡描述，如 "Intel(R) Wi-Fi 6 AX201"
    std::string mode;            // static / dhcp
    std::string ip;
    std::string netmask;
    std::string gateway;
    std::vector<std::string> dns;
};

struct SavedConfig {
    ConfigRecord record;
    std::string filePath;        // UTF-8 完整路径
};

/// 配置文件存储（路径以 UTF-8 表示；纯逻辑，可在 macOS 上单元测试）
class ConfigStore {
public:
    explicit ConfigStore(std::string baseDir);

    const std::string& baseDir() const { return baseDir_; }
    std::string configsDir() const;
    std::string logFile() const;

    void ensureDirs() const;

    /// 列出全部配置（按名称排序，跳过损坏文件）
    std::vector<SavedConfig> list() const;

    /// 保存配置；同名拒绝覆盖
    bool save(const ConfigRecord& record, std::string& error) const;

    /// 删除配置
    bool remove(const SavedConfig& config, std::string& error) const;

    /// 追加操作日志（格式与 macOS 版一致）
    void appendLog(const std::string& entry) const;

    static std::string toJson(const ConfigRecord& record);
    static bool fromJson(const std::string& text, ConfigRecord& out);

private:
    std::string baseDir_;
};
