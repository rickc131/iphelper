#include "json.h"

#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>

namespace jsonx {
namespace {

class Parser {
public:
    explicit Parser(const std::string& text) : s_(text) {}

    bool parseValue(Value& out) {
        skipWs();
        if (index_ >= s_.size()) return fail("内容不完整");

        const char c = s_[index_];
        if (c == '{') return parseObject(out);
        if (c == '[') return parseArray(out);
        if (c == '"') {
            out.type = Value::Type::String;
            return parseString(out.str);
        }
        if (c == 't') {
            if (s_.compare(index_, 4, "true") == 0) {
                index_ += 4;
                out.type = Value::Type::Bool;
                out.boolean = true;
                return true;
            }
            return fail("非法字面量");
        }
        if (c == 'f') {
            if (s_.compare(index_, 5, "false") == 0) {
                index_ += 5;
                out.type = Value::Type::Bool;
                out.boolean = false;
                return true;
            }
            return fail("非法字面量");
        }
        if (c == 'n') {
            if (s_.compare(index_, 4, "null") == 0) {
                index_ += 4;
                out.type = Value::Type::Null;
                return true;
            }
            return fail("非法字面量");
        }
        return parseNumber(out);
    }

    void skipWs() {
        while (index_ < s_.size()) {
            const char c = s_[index_];
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') index_++;
            else break;
        }
    }

    bool atEnd() { return index_ >= s_.size(); }
    const std::string& error() const { return error_; }

private:
    const std::string& s_;
    size_t index_ = 0;
    std::string error_;

    bool fail(const std::string& message) {
        if (error_.empty()) {
            error_ = message + "（位置 " + std::to_string(index_) + "）";
        }
        return false;
    }

    static void appendUtf8(std::string& out, unsigned codePoint) {
        if (codePoint <= 0x7F) {
            out.push_back(static_cast<char>(codePoint));
        } else if (codePoint <= 0x7FF) {
            out.push_back(static_cast<char>(0xC0 | (codePoint >> 6)));
            out.push_back(static_cast<char>(0x80 | (codePoint & 0x3F)));
        } else if (codePoint <= 0xFFFF) {
            out.push_back(static_cast<char>(0xE0 | (codePoint >> 12)));
            out.push_back(static_cast<char>(0x80 | ((codePoint >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (codePoint & 0x3F)));
        } else {
            out.push_back(static_cast<char>(0xF0 | (codePoint >> 18)));
            out.push_back(static_cast<char>(0x80 | ((codePoint >> 12) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | ((codePoint >> 6) & 0x3F)));
            out.push_back(static_cast<char>(0x80 | (codePoint & 0x3F)));
        }
    }

    static int hexValue(char c) {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return -1;
    }

    bool parseHex4(unsigned& out) {
        if (index_ + 4 > s_.size()) return fail("\\u 转义不完整");
        unsigned value = 0;
        for (int i = 0; i < 4; ++i) {
            const int h = hexValue(s_[index_ + static_cast<size_t>(i)]);
            if (h < 0) return fail("\\u 转义非法");
            value = value * 16u + static_cast<unsigned>(h);
        }
        index_ += 4;
        out = value;
        return true;
    }

    bool parseString(std::string& out) {
        if (index_ >= s_.size() || s_[index_] != '"') return fail("期望字符串");
        index_++;
        while (index_ < s_.size()) {
            const char c = s_[index_];
            if (c == '"') {
                index_++;
                return true;
            }
            if (c == '\\') {
                index_++;
                if (index_ >= s_.size()) return fail("字符串未结束");
                const char esc = s_[index_++];
                switch (esc) {
                    case '"': out.push_back('"'); break;
                    case '\\': out.push_back('\\'); break;
                    case '/': out.push_back('/'); break;
                    case 'b': out.push_back('\b'); break;
                    case 'f': out.push_back('\f'); break;
                    case 'n': out.push_back('\n'); break;
                    case 'r': out.push_back('\r'); break;
                    case 't': out.push_back('\t'); break;
                    case 'u': {
                        unsigned codePoint = 0;
                        if (!parseHex4(codePoint)) return false;
                        if (codePoint >= 0xD800 && codePoint <= 0xDBFF) {
                            // 代理对：需要紧随其后的低位代理
                            if (index_ + 1 < s_.size() && s_[index_] == '\\' && s_[index_ + 1] == 'u') {
                                index_ += 2;
                                unsigned low = 0;
                                if (!parseHex4(low)) return false;
                                if (low >= 0xDC00 && low <= 0xDFFF) {
                                    codePoint = 0x10000u + ((codePoint - 0xD800u) << 10) + (low - 0xDC00u);
                                } else {
                                    appendUtf8(out, codePoint);
                                    codePoint = low;
                                }
                            }
                        }
                        appendUtf8(out, codePoint);
                        break;
                    }
                    default:
                        return fail("非法转义字符");
                }
                continue;
            }
            out.push_back(c);
            index_++;
        }
        return fail("字符串未结束");
    }

    bool parseNumber(Value& out) {
        const size_t start = index_;
        if (index_ < s_.size() && (s_[index_] == '-' || s_[index_] == '+')) index_++;
        while (index_ < s_.size()) {
            const char c = s_[index_];
            if ((c >= '0' && c <= '9') || c == '.' || c == 'e' || c == 'E' || c == '+' || c == '-') index_++;
            else break;
        }
        if (index_ == start) return fail("非法数字");
        out.type = Value::Type::Number;
        out.number = std::strtod(s_.substr(start, index_ - start).c_str(), nullptr);
        return true;
    }

    bool parseObject(Value& out) {
        out.type = Value::Type::Object;
        index_++; // '{'
        skipWs();
        if (index_ < s_.size() && s_[index_] == '}') {
            index_++;
            return true;
        }
        while (true) {
            skipWs();
            std::string key;
            if (!parseString(key)) return false;
            skipWs();
            if (index_ >= s_.size() || s_[index_] != ':') return fail("期望冒号");
            index_++;
            Value value;
            if (!parseValue(value)) return false;
            out.obj.emplace_back(key, std::move(value));
            skipWs();
            if (index_ < s_.size() && s_[index_] == ',') {
                index_++;
                continue;
            }
            if (index_ < s_.size() && s_[index_] == '}') {
                index_++;
                return true;
            }
            return fail("对象未结束");
        }
    }

    bool parseArray(Value& out) {
        out.type = Value::Type::Array;
        index_++; // '['
        skipWs();
        if (index_ < s_.size() && s_[index_] == ']') {
            index_++;
            return true;
        }
        while (true) {
            Value value;
            if (!parseValue(value)) return false;
            out.arr.push_back(std::move(value));
            skipWs();
            if (index_ < s_.size() && s_[index_] == ',') {
                index_++;
                continue;
            }
            if (index_ < s_.size() && s_[index_] == ']') {
                index_++;
                return true;
            }
            return fail("数组未结束");
        }
    }
};

void writeString(std::string& out, const std::string& value) {
    out.push_back('"');
    for (const unsigned char c : value) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    std::snprintf(buf, sizeof buf, "\\u%04x", c);
                    out += buf;
                } else {
                    out.push_back(static_cast<char>(c)); // UTF-8 原样输出
                }
        }
    }
    out.push_back('"');
}

void writeValue(std::string& out, const Value& value, int indent) {
    const std::string pad(static_cast<size_t>(indent) * 2, ' ');
    const std::string padInner(static_cast<size_t>(indent + 1) * 2, ' ');

    switch (value.type) {
        case Value::Type::Null:
            out += "null";
            break;
        case Value::Type::Bool:
            out += value.boolean ? "true" : "false";
            break;
        case Value::Type::Number: {
            char buf[64];
            if (value.number == static_cast<double>(static_cast<long long>(value.number))) {
                std::snprintf(buf, sizeof buf, "%lld", static_cast<long long>(value.number));
            } else {
                std::snprintf(buf, sizeof buf, "%g", value.number);
            }
            out += buf;
            break;
        }
        case Value::Type::String:
            writeString(out, value.str);
            break;
        case Value::Type::Array: {
            if (value.arr.empty()) {
                out += "[]";
                break;
            }
            out += "[\n";
            for (size_t i = 0; i < value.arr.size(); ++i) {
                out += padInner;
                writeValue(out, value.arr[i], indent + 1);
                if (i + 1 < value.arr.size()) out += ",";
                out += "\n";
            }
            out += pad + "]";
            break;
        }
        case Value::Type::Object: {
            if (value.obj.empty()) {
                out += "{}";
                break;
            }
            out += "{\n";
            for (size_t i = 0; i < value.obj.size(); ++i) {
                out += padInner;
                writeString(out, value.obj[i].first);
                out += ": ";
                writeValue(out, value.obj[i].second, indent + 1);
                if (i + 1 < value.obj.size()) out += ",";
                out += "\n";
            }
            out += pad + "}";
            break;
        }
    }
}

} // namespace

const Value* Value::find(const std::string& key) const {
    if (type != Type::Object) return nullptr;
    for (const auto& entry : obj) {
        if (entry.first == key) return &entry.second;
    }
    return nullptr;
}

std::string Value::asString(const std::string& def) const {
    if (type == Type::String) return str;
    if (type == Type::Number) {
        char buf[64];
        std::snprintf(buf, sizeof buf, "%.0f", number);
        return buf;
    }
    return def;
}

bool Value::asBool(bool def) const {
    return type == Type::Bool ? boolean : def;
}

std::vector<std::string> Value::asStringArray() const {
    std::vector<std::string> result;
    if (type != Type::Array) return result;
    for (const auto& item : arr) {
        if (item.type == Type::String) result.push_back(item.str);
    }
    return result;
}

bool parse(const std::string& text, Value& out, std::string* error) {
    Parser parser(text);
    out = Value();
    if (!parser.parseValue(out)) {
        if (error) *error = parser.error().empty() ? "解析失败" : parser.error();
        return false;
    }
    parser.skipWs();
    if (!parser.atEnd()) {
        if (error) *error = "存在多余内容";
        return false;
    }
    return true;
}

std::string stringify(const Value& value) {
    std::string out;
    writeValue(out, value, 0);
    out += "\n";
    return out;
}

} // namespace jsonx
