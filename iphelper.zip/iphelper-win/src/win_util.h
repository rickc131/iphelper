#pragma once

#include <string>
#include <windows.h>

std::wstring utf8ToWide(const std::string& utf8);
std::string wideToUtf8(const std::wstring& wide);

/// UTF-16LE 字节序列（供 -EncodedCommand 使用）
std::string utf16LeBytes(const std::wstring& text);
std::string base64Encode(const std::string& bytes);

/// 执行 PowerShell 脚本（经 -EncodedCommand 传入，规避引号与编码问题）
/// timeoutMs 为 INFINITE 或毫秒；成功启动并结束时返回 true，exitCode 为进程退出码
bool runPowerShell(const std::wstring& script, DWORD timeoutMs, std::string& stdoutUtf8, DWORD& exitCode);

/// 临时文件路径（文件已创建，0 字节）
std::wstring makeTempFilePath();

bool readFileBytes(const std::wstring& path, std::string& out);
void deleteFileIfExists(const std::wstring& path);

/// %APPDATA%\<name>
std::wstring appDataSubDir(const std::wstring& name);

/// 当前 exe 完整路径
std::wstring currentExePath();

bool isAutostartEnabled();
bool setAutostart(bool enabled);
