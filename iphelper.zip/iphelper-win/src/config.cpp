#include "config.h"

#include "json.h"
#include "validate.h"

#include <algorithm>
#include <cstdio>
#include <ctime>
#include <fstream>
#include <sstream>

#if defined(_WIN32)
#include <windows.h>
#else
#include <dirent.h>
#include <sys/stat.h>
#endif

namespace {

#if defined(_WIN32)
std::wstring toWide(const std::string& utf8) {
    if (utf8.empty()) return std::wstring();
    const int len = MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), static_cast<int>(utf8.size()), nullptr, 0);
    if (len <= 0) return std::wstring();
    std::wstring out(static_cast<size_t>(len), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), static_cast<int>(utf8.size()), &out[0], len);
    return out;
}
#endif

bool isDirectory(const std::string& path) {
#if defined(_WIN32)
    const DWORD attrs = GetFileAttributesW(toWide(path).c_str());
    return attrs != INVALID_FILE_ATTRIBUTES && (attrs & FILE_ATTRIBUTE_DIRECTORY) != 0;
#else
    struct stat st;
    return ::stat(path.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
#endif
}

bool fileExists(const std::string& path) {
#if defined(_WIN32)
    const DWORD attrs = GetFileAttributesW(toWide(path).c_str());
    return attrs != INVALID_FILE_ATTRIBUTES && (attrs & FILE_ATTRIBUTE_DIRECTORY) == 0;
#else
    struct stat st;
    return ::stat(path.c_str(), &st) == 0 && S_ISREG(st.st_mode);
#endif
}

bool makeDirectory(const std::string& path) {
#if defined(_WIN32)
    return CreateDirectoryW(toWide(path).c_str(), nullptr) != 0;
#else
    return ::mkdir(path.c_str(), 0755) == 0;
#endif
}

bool readFile(const std::string& path, std::string& out) {
#if defined(_WIN32)
    HANDLE handle = CreateFileW(toWide(path).c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr,
                                OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (handle == INVALID_HANDLE_VALUE) return false;
    const DWORD size = GetFileSize(handle, nullptr);
    out.clear();
    if (size != INVALID_FILE_SIZE && size > 0) {
        out.resize(size);
        DWORD read = 0;
        if (!ReadFile(handle, &out[0], size, &read, nullptr)) {
            CloseHandle(handle);
            return false;
        }
        out.resize(read);
    }
    CloseHandle(handle);
    return true;
#else
    std::ifstream in(path, std::ios::binary);
    if (!in) return false;
    std::ostringstream ss;
    ss << in.rdbuf();
    out = ss.str();
    return true;
#endif
}

bool writeFile(const std::string& path, const std::string& data) {
#if defined(_WIN32)
    HANDLE handle = CreateFileW(toWide(path).c_str(), GENERIC_WRITE, 0, nullptr,
                                CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (handle == INVALID_HANDLE_VALUE) return false;
    DWORD written = 0;
    const bool ok = WriteFile(handle, data.data(), static_cast<DWORD>(data.size()), &written, nullptr) != 0;
    CloseHandle(handle);
    return ok;
#else
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) return false;
    out.write(data.data(), static_cast<std::streamsize>(data.size()));
    return out.good();
#endif
}

bool appendFile(const std::string& path, const std::string& data) {
#if defined(_WIN32)
    HANDLE handle = CreateFileW(toWide(path).c_str(), FILE_APPEND_DATA, FILE_SHARE_READ, nullptr,
                                OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (handle == INVALID_HANDLE_VALUE) return false;
    SetFilePointer(handle, 0, nullptr, FILE_END);
    DWORD written = 0;
    const bool ok = WriteFile(handle, data.data(), static_cast<DWORD>(data.size()), &written, nullptr) != 0;
    CloseHandle(handle);
    return ok;
#else
    std::ofstream out(path, std::ios::binary | std::ios::app);
    if (!out) return false;
    out.write(data.data(), static_cast<std::streamsize>(data.size()));
    return out.good();
#endif
}

bool removeFile(const std::string& path) {
#if defined(_WIN32)
    return DeleteFileW(toWide(path).c_str()) != 0;
#else
    return std::remove(path.c_str()) == 0;
#endif
}

std::vector<std::string> listFiles(const std::string& dir) {
    std::vector<std::string> files;
#if defined(_WIN32)
    const std::wstring pattern = toWide(dir + "\\*");
    WIN32_FIND_DATAW data;
    HANDLE handle = FindFirstFileW(pattern.c_str(), &data);
    if (handle == INVALID_HANDLE_VALUE) return files;
    do {
        if ((data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0) continue;
        const int len = WideCharToMultiByte(CP_UTF8, 0, data.cFileName, -1, nullptr, 0, nullptr, nullptr);
        if (len <= 0) continue;
        std::string name(static_cast<size_t>(len), '\0');
        WideCharToMultiByte(CP_UTF8, 0, data.cFileName, -1, &name[0], len, nullptr, nullptr);
        name.resize(static_cast<size_t>(len) - 1);
        files.push_back(name);
    } while (FindNextFileW(handle, &data));
    FindClose(handle);
#else
    DIR* dirHandle = opendir(dir.c_str());
    if (!dirHandle) return files;
    while (struct dirent* entry = readdir(dirHandle)) {
        const std::string name = entry->d_name;
        if (name == "." || name == "..") continue;
        if (isDirectory(dir + "/" + name)) continue;
        files.push_back(name);
    }
    closedir(dirHandle);
#endif
    return files;
}

std::string joinPath(const std::string& dir, const std::string& name) {
#if defined(_WIN32)
    return dir + "\\" + name;
#else
    return dir + "/" + name;
#endif
}

bool endsWith(const std::string& text, const std::string& suffix) {
    return text.size() >= suffix.size() &&
           text.compare(text.size() - suffix.size(), suffix.size(), suffix) == 0;
}

} // namespace

ConfigStore::ConfigStore(std::string baseDir) : baseDir_(std::move(baseDir)) {}

std::string ConfigStore::configsDir() const { return joinPath(baseDir_, "configs"); }

std::string ConfigStore::logFile() const { return joinPath(baseDir_, "log.txt"); }

void ConfigStore::ensureDirs() const {
    if (!isDirectory(baseDir_)) makeDirectory(baseDir_);
    if (!isDirectory(configsDir())) makeDirectory(configsDir());
}

std::string ConfigStore::toJson(const ConfigRecord& record) {
    jsonx::Value root;
    root.type = jsonx::Value::Type::Object;

    auto text = [](const std::string& value) {
        jsonx::Value v;
        v.type = jsonx::Value::Type::String;
        v.str = value;
        return v;
    };
    auto put = [&root](const std::string& key, jsonx::Value value) {
        root.obj.emplace_back(key, std::move(value));
    };

    put("name", text(record.name));
    put("interface", text(record.interfaceName));
    put("serviceName", text(record.serviceName));
    put("mode", text(record.mode.empty() ? "static" : record.mode));
    put("ip", text(record.ip));
    put("netmask", text(record.netmask));
    put("gateway", text(record.gateway));

    jsonx::Value dns;
    dns.type = jsonx::Value::Type::Array;
    for (const auto& server : record.dns) dns.arr.push_back(text(server));
    put("dns", std::move(dns));

    return jsonx::stringify(root);
}

bool ConfigStore::fromJson(const std::string& text, ConfigRecord& out) {
    jsonx::Value root;
    std::string error;
    if (!jsonx::parse(text, root, &error)) return false;

    const jsonx::Value* name = root.find("name");
    if (!name) return false;

    out = ConfigRecord();
    out.name = name->asString();
    if (const jsonx::Value* v = root.find("interface")) out.interfaceName = v->asString();
    if (const jsonx::Value* v = root.find("serviceName")) out.serviceName = v->asString();
    if (const jsonx::Value* v = root.find("mode")) out.mode = v->asString();
    if (const jsonx::Value* v = root.find("ip")) out.ip = v->asString();
    if (const jsonx::Value* v = root.find("netmask")) out.netmask = v->asString();
    if (const jsonx::Value* v = root.find("gateway")) out.gateway = v->asString();
    if (const jsonx::Value* v = root.find("dns")) out.dns = v->asStringArray();
    if (out.mode.empty()) out.mode = out.ip.empty() ? "dhcp" : "static";
    return true;
}

std::vector<SavedConfig> ConfigStore::list() const {
    ensureDirs();

    std::vector<SavedConfig> result;
    for (const auto& file : listFiles(configsDir())) {
        if (!endsWith(file, ".json")) continue;
        const std::string path = joinPath(configsDir(), file);
        std::string text;
        if (!readFile(path, text)) continue;
        ConfigRecord record;
        if (!fromJson(text, record)) continue;
        result.push_back(SavedConfig{record, path});
    }

    std::sort(result.begin(), result.end(), [](const SavedConfig& a, const SavedConfig& b) {
        return a.record.name < b.record.name;
    });
    return result;
}

bool ConfigStore::save(const ConfigRecord& record, std::string& error) const {
    ensureDirs();

    const std::string fileName = safeFileName(record.name);
    const std::string path = joinPath(configsDir(), fileName + ".json");
    if (fileExists(path)) {
        error = "配置「" + fileName + "」已存在，请使用其他名称";
        return false;
    }
    if (!writeFile(path, toJson(record))) {
        error = "写入配置文件失败：" + path;
        return false;
    }
    appendLog("保存配置: " + fileName);
    return true;
}

bool ConfigStore::remove(const SavedConfig& config, std::string& error) const {
    if (!removeFile(config.filePath)) {
        error = "删除文件失败：" + config.filePath;
        return false;
    }
    appendLog("删除配置: " + config.record.name);
    return true;
}

void ConfigStore::appendLog(const std::string& entry) const {
    std::time_t now = std::time(nullptr);
    std::tm local{};
#if defined(_WIN32)
    localtime_s(&local, &now);
#else
    local = *std::localtime(&now);
#endif
    char stamp[32] = {0};
    std::strftime(stamp, sizeof stamp, "%Y-%m-%d %H:%M:%S", &local);

    ensureDirs();
    appendFile(logFile(), std::string("[") + stamp + "] " + entry + "\n");
}
