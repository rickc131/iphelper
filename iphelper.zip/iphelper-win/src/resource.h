#pragma once

// 资源 ID（与 resources/app.rc 对应）
#define IDI_APPICON 101
