#include <windows.h>

#include <shellapi.h>
#include <commctrl.h>

#include "config.h"
#include "network.h"
#include "resource.h"
#include "save_dialog.h"
#include "validate.h"
#include "win_util.h"

#include <string>
#include <vector>

namespace {

const UINT WM_TRAY_MSG = WM_APP + 1;
const UINT WM_WORK_DONE = WM_APP + 2;

enum : UINT {
    IDM_SAVE_CONFIG = 100,
    IDM_OPEN_CONFIGS,
    IDM_OPEN_LOG,
    IDM_AUTOSTART,
    IDM_QUIT,
    IDM_CONFIG_BASE = 1000,
    IDM_DHCP_BASE = 2000,
    IDM_DELETE_BASE = 3000,
};

HINSTANCE g_instance = nullptr;
HWND g_window = nullptr;
NOTIFYICONDATAW g_nid{};
ConfigStore* g_store = nullptr;
std::vector<SavedConfig> g_configs;
std::vector<Adapter> g_adapters;
DWORD g_adaptersLoadedAt = 0;
UINT g_taskbarCreatedMessage = 0;
bool g_modalOpen = false;
bool g_busy = false;

struct WorkItem {
    bool dhcpOnly = false;   // true：直接恢复 DHCP（无配置存档）
    ConfigRecord record;
    std::string adapter;     // DHCP 目标网卡（UTF-8）
};

struct WorkResult {
    bool success = false;
    bool canceled = false;
    std::wstring title;
    std::wstring detail;
    std::wstring tooltip;
    std::wstring balloon;
};

const wchar_t* kDefaultTip = L"IPHelper · 点击选择要切换的网络配置";

void setTip(const std::wstring& text) {
    g_nid.uFlags = NIF_TIP;
    wcsncpy(g_nid.szTip, text.c_str(), 127);
    g_nid.szTip[127] = L'\0';
    Shell_NotifyIconW(NIM_MODIFY, &g_nid);
}

void showBalloon(const std::wstring& title, const std::wstring& text) {
    NOTIFYICONDATAW nid = g_nid;
    nid.uFlags = NIF_INFO;
    nid.dwInfoFlags = NIIF_INFO;
    nid.uTimeout = 5000;
    wcsncpy(nid.szInfoTitle, title.c_str(), 63);
    nid.szInfoTitle[63] = L'\0';
    wcsncpy(nid.szInfo, text.c_str(), 255);
    nid.szInfo[255] = L'\0';
    Shell_NotifyIconW(NIM_MODIFY, &nid);
}

void warn(const std::wstring& title, const std::wstring& detail) {
    MessageBoxW(g_window, detail.c_str(), title.c_str(), MB_OK | MB_ICONWARNING);
}

/// 网卡列表带 30 秒缓存，避免每次展开菜单都等 PowerShell
void ensureAdapters(bool force = false) {
    const DWORD now = GetTickCount();
    if (!force && !g_adapters.empty() && now - g_adaptersLoadedAt < 30000) return;

    std::vector<Adapter> adapters = listAdapters(nullptr);
    if (!adapters.empty() || g_adapters.empty()) {
        g_adapters = adapters;
        g_adaptersLoadedAt = GetTickCount();
    }
}

void addMenuItem(HMENU menu, UINT flags, UINT_PTR id, const std::wstring& text) {
    AppendMenuW(menu, flags, id, text.c_str());
}

HMENU buildMenu() {
    HMENU menu = CreatePopupMenu();
    addMenuItem(menu, MF_STRING | MF_DISABLED, 0, L"IPHelper");

    g_configs = g_store->list();
    if (g_configs.empty()) {
        addMenuItem(menu, MF_STRING | MF_DISABLED, 0, L"（暂无已保存配置）");
    } else {
        for (size_t i = 0; i < g_configs.size(); ++i) {
            const std::wstring tag = (g_configs[i].record.mode == "dhcp") ? L"DHCP" : L"静态";
            addMenuItem(menu, MF_STRING, IDM_CONFIG_BASE + i,
                        utf8ToWide(g_configs[i].record.name) + L"（" + tag + L"）");
        }
    }

    AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);
    addMenuItem(menu, MF_STRING, IDM_SAVE_CONFIG, L"保存当前配置…");

    ensureAdapters();
    if (g_adapters.empty()) {
        addMenuItem(menu, MF_STRING | MF_DISABLED, 0, L"恢复 DHCP（未找到网卡）");
    } else {
        HMENU submenu = CreatePopupMenu();
        for (size_t i = 0; i < g_adapters.size(); ++i) {
            addMenuItem(submenu, MF_STRING, IDM_DHCP_BASE + i,
                        g_adapters[i].name + L"（" + g_adapters[i].description + L"）");
        }
        addMenuItem(menu, MF_POPUP, reinterpret_cast<UINT_PTR>(submenu), L"恢复 DHCP");
    }

    if (!g_configs.empty()) {
        HMENU submenu = CreatePopupMenu();
        for (size_t i = 0; i < g_configs.size(); ++i) {
            addMenuItem(submenu, MF_STRING, IDM_DELETE_BASE + i, utf8ToWide(g_configs[i].record.name));
        }
        addMenuItem(menu, MF_POPUP, reinterpret_cast<UINT_PTR>(submenu), L"删除配置");
    }

    AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);
    addMenuItem(menu, MF_STRING, IDM_OPEN_CONFIGS, L"打开配置目录");
    addMenuItem(menu, MF_STRING, IDM_OPEN_LOG, L"查看日志");
    addMenuItem(menu, MF_STRING | (isAutostartEnabled() ? MF_CHECKED : 0), IDM_AUTOSTART, L"开机自启动");
    AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);
    addMenuItem(menu, MF_STRING, IDM_QUIT, L"退出 IPHelper");
    return menu;
}

void showTrayMenu() {
    if (g_modalOpen) return;

    HMENU menu = buildMenu();
    POINT point{};
    GetCursorPos(&point);
    SetForegroundWindow(g_window);
    TrackPopupMenu(menu, TPM_RIGHTBUTTON, point.x, point.y, 0, g_window, nullptr);
    DestroyMenu(menu);
    PostMessageW(g_window, WM_NULL, 0, 0); // 规避菜单残留
}

DWORD WINAPI workerThread(LPVOID parameter) {
    WorkItem* item = static_cast<WorkItem*>(parameter);
    auto* result = new WorkResult();

    std::wstring error;
    bool canceled = false;

    if (item->dhcpOnly) {
        const bool ok = applyDhcp(item->adapter, error, canceled);
        result->success = ok;
        result->canceled = canceled;
        result->title = L"切换 DHCP 失败";
        result->detail = error;
        result->balloon = L"已切换为 DHCP";
        result->tooltip = ok ? L"IPHelper" : kDefaultTip;
        if (ok) g_store->appendLog("切换DHCP: " + item->adapter);
    } else {
        const bool ok = applyConfig(item->record, error, canceled);
        result->success = ok;
        result->canceled = canceled;
        result->title = L"未能应用配置「" + utf8ToWide(item->record.name) + L"」";
        result->detail = error;
        result->balloon = L"已应用配置「" + utf8ToWide(item->record.name) + L"」";
        result->tooltip = ok ? (L"IPHelper · 当前：" + utf8ToWide(item->record.name)) : kDefaultTip;
        if (ok) {
            g_store->appendLog("设置静态IP: " + item->record.interfaceName + " → " + item->record.ip +
                               "/" + item->record.netmask + " gw=" + item->record.gateway);
        }
    }

    delete item;
    PostMessageW(g_window, WM_WORK_DONE, 0, reinterpret_cast<LPARAM>(result));
    return 0;
}

void startWork(WorkItem* item) {
    if (g_busy) {
        delete item;
        return;
    }
    g_busy = true;
    setTip(L"IPHelper · 正在执行…");
    HANDLE thread = CreateThread(nullptr, 0, workerThread, item, 0, nullptr);
    if (!thread) {
        g_busy = false;
        delete item;
        setTip(kDefaultTip);
        warn(L"IPHelper", L"无法创建后台任务。");
        return;
    }
    CloseHandle(thread);
}

void applySavedConfig(const SavedConfig& config) {
    WorkItem* item = new WorkItem();
    item->dhcpOnly = false;
    item->record = config.record;
    startWork(item);
}

void switchToDhcp(const Adapter& adapter) {
    WorkItem* item = new WorkItem();
    item->dhcpOnly = true;
    item->adapter = wideToUtf8(adapter.name);
    startWork(item);
}

void deleteSavedConfig(const SavedConfig& config) {
    const std::wstring message = L"确认删除配置「" + utf8ToWide(config.record.name) + L"」？此操作不可撤销。";
    if (MessageBoxW(g_window, message.c_str(), L"IPHelper", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2) != IDYES) {
        return;
    }
    std::string error;
    if (!g_store->remove(config, error)) {
        warn(L"删除配置失败", utf8ToWide(error));
    }
}

void onSaveConfig() {
    g_modalOpen = true;
    const bool saved = showSaveDialog(g_window, *g_store);
    g_modalOpen = false;
    ensureAdapters(true);
    if (saved) showBalloon(L"IPHelper", L"当前配置已保存");
}

void openPath(const std::wstring& path) {
    ShellExecuteW(nullptr, L"open", path.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

void onOpenConfigs() {
    g_store->ensureDirs();
    openPath(utf8ToWide(g_store->configsDir()));
}

void onOpenLog() {
    if (GetFileAttributesW(utf8ToWide(g_store->logFile()).c_str()) == INVALID_FILE_ATTRIBUTES) {
        g_store->appendLog("IPHelper 启动");
    }
    openPath(utf8ToWide(g_store->logFile()));
}

void onToggleAutostart() {
    const bool target = !isAutostartEnabled();
    if (!setAutostart(target)) {
        warn(L"设置开机自启动失败", L"无法写入注册表启动项（HKCU\\...\\Run）。");
    }
}

LRESULT CALLBACK windowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (msg == g_taskbarCreatedMessage && g_taskbarCreatedMessage != 0) {
        Shell_NotifyIconW(NIM_ADD, &g_nid);
        return 0;
    }

    switch (msg) {
        case WM_TRAY_MSG:
            switch (LOWORD(lParam)) {
                case WM_LBUTTONUP:
                case WM_RBUTTONUP:
                case WM_CONTEXTMENU:
                    showTrayMenu();
                    break;
                default:
                    break;
            }
            return 0;

        case WM_WORK_DONE: {
            g_busy = false;
            auto* result = reinterpret_cast<WorkResult*>(lParam);
            if (result) {
                setTip(result->tooltip);
                if (result->success) {
                    showBalloon(L"IPHelper", result->balloon);
                    ensureAdapters(true);
                } else if (!result->canceled) {
                    warn(result->title, result->detail);
                }
                delete result;
            }
            return 0;
        }

        case WM_COMMAND: {
            const UINT id = LOWORD(wParam);
            if (id >= IDM_CONFIG_BASE && id < IDM_CONFIG_BASE + g_configs.size()) {
                applySavedConfig(g_configs[id - IDM_CONFIG_BASE]);
                return 0;
            }
            if (id >= IDM_DHCP_BASE && id < IDM_DHCP_BASE + g_adapters.size()) {
                switchToDhcp(g_adapters[id - IDM_DHCP_BASE]);
                return 0;
            }
            if (id >= IDM_DELETE_BASE && id < IDM_DELETE_BASE + g_configs.size()) {
                deleteSavedConfig(g_configs[id - IDM_DELETE_BASE]);
                return 0;
            }
            switch (id) {
                case IDM_SAVE_CONFIG: onSaveConfig(); return 0;
                case IDM_OPEN_CONFIGS: onOpenConfigs(); return 0;
                case IDM_OPEN_LOG: onOpenLog(); return 0;
                case IDM_AUTOSTART: onToggleAutostart(); return 0;
                case IDM_QUIT: DestroyWindow(hwnd); return 0;
                default: break;
            }
            break;
        }

        case WM_DESTROY:
            Shell_NotifyIconW(NIM_DELETE, &g_nid);
            PostQuitMessage(0);
            return 0;

        case WM_ENDSESSION:
        case WM_QUERYENDSESSION:
            return TRUE;

        default:
            break;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

} // namespace

int WINAPI WinMain(HINSTANCE instance, HINSTANCE, LPSTR, int) {
    HANDLE mutex = CreateMutexW(nullptr, TRUE, L"Local\\IPHelper-Tray-SingleInstance-v1");
    if (mutex && GetLastError() == ERROR_ALREADY_EXISTS) {
        if (mutex) CloseHandle(mutex);
        return 0;
    }

    g_instance = instance;
    g_taskbarCreatedMessage = RegisterWindowMessageW(L"TaskbarCreated");

    INITCOMMONCONTROLSEX controls{};
    controls.dwSize = sizeof(controls);
    controls.dwICC = ICC_STANDARD_CLASSES;
    InitCommonControlsEx(&controls);

    static ConfigStore store(wideToUtf8(appDataSubDir(L"iphelper")));
    g_store = &store;
    store.ensureDirs();

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = windowProc;
    wc.hInstance = instance;
    wc.lpszClassName = L"IPHelperTrayWindow";
    wc.hIcon = reinterpret_cast<HICON>(LoadImageW(instance, MAKEINTRESOURCEW(IDI_APPICON), IMAGE_ICON,
                                                  0, 0, LR_DEFAULTSIZE));
    wc.hIconSm = reinterpret_cast<HICON>(LoadImageW(instance, MAKEINTRESOURCEW(IDI_APPICON), IMAGE_ICON,
                                                    GetSystemMetrics(SM_CXSMICON),
                                                    GetSystemMetrics(SM_CYSMICON), 0));
    if (!RegisterClassExW(&wc)) return 1;

    g_window = CreateWindowExW(WS_EX_TOOLWINDOW, L"IPHelperTrayWindow", L"IPHelper", WS_POPUP,
                               0, 0, 0, 0, nullptr, nullptr, instance, nullptr);
    if (!g_window) return 1;

    g_nid.cbSize = sizeof(g_nid);
    g_nid.hWnd = g_window;
    g_nid.uID = 1;
    g_nid.uCallbackMessage = WM_TRAY_MSG;
    g_nid.hIcon = reinterpret_cast<HICON>(LoadImageW(instance, MAKEINTRESOURCEW(IDI_APPICON), IMAGE_ICON,
                                                     GetSystemMetrics(SM_CXSMICON),
                                                     GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR));
    if (!g_nid.hIcon) {
        g_nid.hIcon = reinterpret_cast<HICON>(LoadImageW(instance, MAKEINTRESOURCEW(IDI_APPICON),
                                                         IMAGE_ICON, 0, 0, LR_DEFAULTSIZE));
    }
    g_nid.uFlags = NIF_MESSAGE | NIF_TIP | (g_nid.hIcon ? NIF_ICON : 0);
    wcsncpy(g_nid.szTip, kDefaultTip, 127);
    g_nid.szTip[127] = L'\0';
    Shell_NotifyIconW(NIM_ADD, &g_nid);

    ensureAdapters(true);

    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    if (mutex) CloseHandle(mutex);
    return 0;
}
