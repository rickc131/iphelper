#pragma once

// 极简 JSON 解析/序列化（仅用于本应用的配置文件）
// 纯标准 C++，可在 macOS 上直接编译做单元测试
#include <string>
#include <utility>
#include <vector>

namespace jsonx {

struct Value;

using ObjectEntries = std::vector<std::pair<std::string, Value>>;

struct Value {
    enum class Type { Null, Bool, Number, String, Array, Object };

    Type type = Type::Null;
    bool boolean = false;
    double number = 0;
    std::string str;   // UTF-8
    std::vector<Value> arr;
    ObjectEntries obj;

    bool isNull() const { return type == Type::Null; }

    /// 对象取字段；不存在返回 nullptr
    const Value* find(const std::string& key) const;

    std::string asString(const std::string& def = "") const;
    bool asBool(bool def = false) const;
    std::vector<std::string> asStringArray() const;
};

/// 解析 JSON 文本（UTF-8）；失败返回 false 并写入 error
bool parse(const std::string& text, Value& out, std::string* error = nullptr);

/// 序列化（2 空格缩进；非 ASCII 原样输出，便于中文可读）
std::string stringify(const Value& value);

} // namespace jsonx
