#pragma once

// PowerShell 脚本文本生成（纯标准 C++，无 Windows 依赖）
// 抽成独立模块的原因：脚本内容是本项目唯一无法在 macOS 上执行的部分，
// 独立后可在本机生成并做内容断言/人工审阅。
#include <string>
#include <vector>

/// PowerShell 单引号字符串转义（' → ''）
std::wstring escapePsSingleQuoted(const std::wstring& text);

/// 提权后的执行脚本：逐条执行 netsh 命令；全部成功写 "OK"，失败写错误详情
std::wstring buildNetshWorkerScript(const std::vector<std::wstring>& netshCommandLines,
                                    const std::wstring& statusFile);

/// 非提权启动器：用 -Verb RunAs 拉起上面的 worker（触发 UAC），并回传退出码
std::wstring buildElevationLauncherScript(const std::string& workerBase64,
                                          const std::wstring& statusFile);
