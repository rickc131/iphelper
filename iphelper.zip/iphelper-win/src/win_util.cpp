#include "win_util.h"

#include <cstdio>
#include <vector>

std::wstring utf8ToWide(const std::string& utf8) {
    if (utf8.empty()) return std::wstring();
    const int len = MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), static_cast<int>(utf8.size()), nullptr, 0);
    if (len <= 0) return std::wstring();
    std::wstring out(static_cast<size_t>(len), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), static_cast<int>(utf8.size()), &out[0], len);
    return out;
}

std::string wideToUtf8(const std::wstring& wide) {
    if (wide.empty()) return std::string();
    const int len = WideCharToMultiByte(CP_UTF8, 0, wide.c_str(), static_cast<int>(wide.size()),
                                        nullptr, 0, nullptr, nullptr);
    if (len <= 0) return std::string();
    std::string out(static_cast<size_t>(len), '\0');
    WideCharToMultiByte(CP_UTF8, 0, wide.c_str(), static_cast<int>(wide.size()),
                        &out[0], len, nullptr, nullptr);
    return out;
}

std::string utf16LeBytes(const std::wstring& text) {
    std::string bytes;
    bytes.resize(text.size() * 2);
    for (size_t i = 0; i < text.size(); ++i) {
        const wchar_t c = text[i];
        bytes[i * 2] = static_cast<char>(c & 0xFF);
        bytes[i * 2 + 1] = static_cast<char>((c >> 8) & 0xFF);
    }
    return bytes;
}

std::string base64Encode(const std::string& bytes) {
    static const char* kTable = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string out;
    out.reserve((bytes.size() + 2) / 3 * 4);

    size_t i = 0;
    while (i + 3 <= bytes.size()) {
        const unsigned triple = (static_cast<unsigned char>(bytes[i]) << 16) |
                                (static_cast<unsigned char>(bytes[i + 1]) << 8) |
                                static_cast<unsigned char>(bytes[i + 2]);
        out.push_back(kTable[(triple >> 18) & 0x3F]);
        out.push_back(kTable[(triple >> 12) & 0x3F]);
        out.push_back(kTable[(triple >> 6) & 0x3F]);
        out.push_back(kTable[triple & 0x3F]);
        i += 3;
    }

    const size_t rest = bytes.size() - i;
    if (rest == 1) {
        const unsigned triple = static_cast<unsigned char>(bytes[i]) << 16;
        out.push_back(kTable[(triple >> 18) & 0x3F]);
        out.push_back(kTable[(triple >> 12) & 0x3F]);
        out.push_back('=');
        out.push_back('=');
    } else if (rest == 2) {
        const unsigned triple = (static_cast<unsigned char>(bytes[i]) << 16) |
                                (static_cast<unsigned char>(bytes[i + 1]) << 8);
        out.push_back(kTable[(triple >> 18) & 0x3F]);
        out.push_back(kTable[(triple >> 12) & 0x3F]);
        out.push_back(kTable[(triple >> 6) & 0x3F]);
        out.push_back('=');
    }
    return out;
}

bool runPowerShell(const std::wstring& script, DWORD timeoutMs, std::string& stdoutUtf8, DWORD& exitCode) {
    stdoutUtf8.clear();
    exitCode = 1;

    const std::string encoded = base64Encode(utf16LeBytes(script));
    std::wstring commandLine = L"powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand ";
    commandLine += utf8ToWide(encoded);

    SECURITY_ATTRIBUTES sa{};
    sa.nLength = sizeof(sa);
    sa.bInheritHandle = TRUE;

    HANDLE readPipe = nullptr;
    HANDLE writePipe = nullptr;
    if (!CreatePipe(&readPipe, &writePipe, &sa, 0)) return false;
    SetHandleInformation(readPipe, HANDLE_FLAG_INHERIT, 0);

    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    si.hStdOutput = writePipe;
    si.hStdError = writePipe;
    si.hStdInput = nullptr;

    PROCESS_INFORMATION pi{};
    std::vector<wchar_t> mutableCmd(commandLine.begin(), commandLine.end());
    mutableCmd.push_back(L'\0');

    const BOOL created = CreateProcessW(nullptr, mutableCmd.data(), nullptr, nullptr, TRUE,
                                        CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi);
    CloseHandle(writePipe);

    if (!created) {
        CloseHandle(readPipe);
        return false;
    }

    const DWORD waitResult = WaitForSingleObject(pi.hProcess, timeoutMs);
    if (waitResult == WAIT_TIMEOUT) {
        TerminateProcess(pi.hProcess, 1);
    }

    // 读取输出（我们的脚本输出都很小，不会撑爆管道缓冲）
    char buffer[4096];
    DWORD read = 0;
    while (ReadFile(readPipe, buffer, sizeof buffer, &read, nullptr) && read > 0) {
        stdoutUtf8.append(buffer, read);
    }

    if (waitResult == WAIT_TIMEOUT) {
        WaitForSingleObject(pi.hProcess, 2000);
        exitCode = 1;
    } else {
        DWORD code = 0;
        GetExitCodeProcess(pi.hProcess, &code);
        exitCode = code;
    }

    CloseHandle(readPipe);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);

    // 去掉 UTF-8 BOM
    if (stdoutUtf8.size() >= 3 && static_cast<unsigned char>(stdoutUtf8[0]) == 0xEF &&
        static_cast<unsigned char>(stdoutUtf8[1]) == 0xBB && static_cast<unsigned char>(stdoutUtf8[2]) == 0xBF) {
        stdoutUtf8.erase(0, 3);
    }
    return true;
}

std::wstring makeTempFilePath() {
    wchar_t tempDir[MAX_PATH] = {0};
    const DWORD len = GetTempPathW(MAX_PATH, tempDir);
    if (len == 0 || len > MAX_PATH) return L"";

    wchar_t tempFile[MAX_PATH] = {0};
    if (GetTempFileNameW(tempDir, L"iph", 0, tempFile) == 0) return L"";
    return tempFile;
}

bool readFileBytes(const std::wstring& path, std::string& out) {
    HANDLE handle = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr,
                                OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (handle == INVALID_HANDLE_VALUE) return false;

    out.clear();
    const DWORD size = GetFileSize(handle, nullptr);
    if (size != INVALID_FILE_SIZE && size > 0) {
        out.resize(size);
        DWORD read = 0;
        if (!ReadFile(handle, &out[0], size, &read, nullptr)) {
            CloseHandle(handle);
            return false;
        }
        out.resize(read);
    }
    CloseHandle(handle);
    return true;
}

void deleteFileIfExists(const std::wstring& path) {
    if (!path.empty()) DeleteFileW(path.c_str());
}

std::wstring appDataSubDir(const std::wstring& name) {
    wchar_t buffer[MAX_PATH] = {0};
    const DWORD len = GetEnvironmentVariableW(L"APPDATA", buffer, MAX_PATH);
    std::wstring base = (len > 0 && len < MAX_PATH) ? std::wstring(buffer) : std::wstring(L".");
    return base + L"\\" + name;
}

std::wstring currentExePath() {
    std::vector<wchar_t> buffer(MAX_PATH);
    while (true) {
        const DWORD len = GetModuleFileNameW(nullptr, buffer.data(), static_cast<DWORD>(buffer.size()));
        if (len == 0) return L"";
        if (len < buffer.size() - 1) break;
        buffer.resize(buffer.size() * 2);
    }
    return std::wstring(buffer.data());
}

namespace {
const wchar_t* kRunKey = L"Software\\Microsoft\\Windows\\CurrentVersion\\Run";
const wchar_t* kRunValue = L"IPHelper";
} // namespace

bool isAutostartEnabled() {
    wchar_t buffer[MAX_PATH * 2] = {0};
    DWORD size = sizeof(buffer);
    const LONG result = RegGetValueW(HKEY_CURRENT_USER, kRunKey, kRunValue, RRF_RT_REG_SZ,
                                     nullptr, buffer, &size);
    return result == ERROR_SUCCESS;
}

bool setAutostart(bool enabled) {
    HKEY key = nullptr;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, kRunKey, 0, nullptr, 0, KEY_SET_VALUE,
                        nullptr, &key, nullptr) != ERROR_SUCCESS) {
        return false;
    }

    bool ok = true;
    if (enabled) {
        std::wstring value = L"\"" + currentExePath() + L"\"";
        ok = RegSetValueExW(key, kRunValue, 0, REG_SZ,
                            reinterpret_cast<const BYTE*>(value.c_str()),
                            static_cast<DWORD>((value.size() + 1) * sizeof(wchar_t))) == ERROR_SUCCESS;
    } else {
        const LONG result = RegDeleteValueW(key, kRunValue);
        ok = (result == ERROR_SUCCESS || result == ERROR_FILE_NOT_FOUND);
    }
    RegCloseKey(key);
    return ok;
}
