#pragma once

#include <windows.h>

class ConfigStore;

/// 「保存当前配置」弹窗：选择网卡 + 实时读取当前参数 + 命名保存
/// 返回 true 表示已成功保存
bool showSaveDialog(HWND owner, const ConfigStore& store);
