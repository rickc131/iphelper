#!/bin/bash
# 在本机（macOS）编译并运行纯逻辑自测：JSON / 校验 / 配置存档 / PowerShell 脚本生成
set -euo pipefail
cd "$(dirname "$0")/.."

CXX="${CXX:-clang++}"

echo "==> 1/2 数据层自测（JSON、校验、配置存档）"
"$CXX" -std=c++17 -O1 -Wall -Wextra -I src \
  src/json.cpp src/validate.cpp src/config.cpp tests/selftest.cpp \
  -o /tmp/iphelper-win-selftest-bin
/tmp/iphelper-win-selftest-bin

echo
echo "==> 2/2 PowerShell 脚本生成自测"
"$CXX" -std=c++17 -O1 -Wall -Wextra -I src \
  src/ps_scripts.cpp tests/ps_scripts_test.cpp \
  -o /tmp/iphelper-win-ps-selftest-bin
/tmp/iphelper-win-ps-selftest-bin
