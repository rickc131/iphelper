"use strict";
// 生成 Windows 应用图标 resources/app.ico（蓝色圆角底 + 白色 WiFi 标识）
// 小尺寸用 BMP 条目（兼容性最好），大尺寸用 PNG 条目
// 用法：node tools/make_icon.js
const zlib = require("zlib");
const fs = require("fs");
const path = require("path");

const OUT = path.join(__dirname, "..", "resources", "app.ico");

// ── PNG 编码 ───────────────────────────────────────────────
function crc32(buf) {
  let table = crc32.table;
  if (!table) {
    table = crc32.table = new Int32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      table[n] = c;
    }
  }
  let crc = -1;
  for (let i = 0; i < buf.length; i++) crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
  return (crc ^ -1) >>> 0;
}

function pngChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, "ascii");
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function encodePNG(size, rgba) {
  const sig = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const raw = Buffer.alloc((size * 4 + 1) * size);
  for (let y = 0; y < size; y++) {
    raw[y * (size * 4 + 1)] = 0;
    rgba.copy(raw, y * (size * 4 + 1) + 1, y * size * 4, (y + 1) * size * 4);
  }
  return Buffer.concat([
    sig,
    pngChunk("IHDR", ihdr),
    pngChunk("IDAT", zlib.deflateSync(raw, { level: 9 })),
    pngChunk("IEND", Buffer.alloc(0)),
  ]);
}

// ── ICO 的 BMP 条目（32bpp + AND 掩码）──────────────────────
function bmpEntry(size, rgba) {
  const andStride = Math.ceil(size / 32) * 4;
  const xorSize = size * size * 4;
  const andSize = andStride * size;
  const header = Buffer.alloc(40);
  header.writeUInt32LE(40, 0);
  header.writeInt32LE(size, 4);
  header.writeInt32LE(size * 2, 8); // XOR + AND
  header.writeUInt16LE(1, 12);
  header.writeUInt16LE(32, 14);
  header.writeUInt32LE(0, 16); // BI_RGB
  header.writeUInt32LE(xorSize + andSize, 20);

  const xor = Buffer.alloc(xorSize);
  const and = Buffer.alloc(andSize);
  for (let y = 0; y < size; y++) {
    const srcY = size - 1 - y; // 自下而上
    for (let x = 0; x < size; x++) {
      const s = (srcY * size + x) * 4;
      const d = (y * size + x) * 4;
      xor[d] = rgba[s + 2];
      xor[d + 1] = rgba[s + 1];
      xor[d + 2] = rgba[s];
      xor[d + 3] = rgba[s + 3];
      if (rgba[s + 3] < 128) and[y * andStride + (x >> 3)] |= 0x80 >> (x & 7);
    }
  }
  return Buffer.concat([header, xor, and]);
}

// ── 绘制：蓝色渐变圆角底 + 白色 WiFi 信号 ───────────────────
const TOP = [62, 166, 255];
const BOTTOM = [6, 82, 190];

function insideRoundedRect(px, py, x0, y0, w, h, radius) {
  const halfW = w / 2, halfH = h / 2;
  const qx = Math.abs(px - (x0 + halfW)) - (halfW - radius);
  const qy = Math.abs(py - (y0 + halfH)) - (halfH - radius);
  const d = Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - radius;
  return d <= 0;
}

function insideGlyph(nx, ny) {
  const cx = 0.5, cy = 0.665;
  const radii = [0.155, 0.275, 0.395];
  const halfW = 0.042;
  const dotR = 0.075;
  const dx = nx - cx, dy = ny - cy;
  const d = Math.hypot(dx, dy);
  if (d <= dotR) return true;
  if (ny < cy) {
    for (const r of radii) {
      if (d >= r - halfW && d <= r + halfW) return true;
    }
  }
  return false;
}

function render(size) {
  const S = 4;
  const content = size * 0.804;
  const offset = (size - content) / 2;
  const radius = content * 0.2237;
  const rgba = Buffer.alloc(size * size * 4);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let shapeHits = 0, rSum = 0, gSum = 0, bSum = 0;
      for (let sy = 0; sy < S; sy++) {
        for (let sx = 0; sx < S; sx++) {
          const px = x + (sx + 0.5) / S;
          const py = y + (sy + 0.5) / S;
          if (!insideRoundedRect(px, py, offset, offset, content, content, radius)) continue;
          shapeHits++;
          const nx = (px - offset) / content;
          const ny = (py - offset) / content;
          if (insideGlyph(nx, ny)) {
            rSum += 255; gSum += 255; bSum += 255;
          } else {
            const t = Math.max(0, Math.min(1, ny));
            rSum += TOP[0] + (BOTTOM[0] - TOP[0]) * t;
            gSum += TOP[1] + (BOTTOM[1] - TOP[1]) * t;
            bSum += TOP[2] + (BOTTOM[2] - TOP[2]) * t;
          }
        }
      }
      const idx = (y * size + x) * 4;
      if (shapeHits === 0) {
        rgba[idx] = rgba[idx + 1] = rgba[idx + 2] = rgba[idx + 3] = 0;
      } else {
        rgba[idx] = Math.round(rSum / shapeHits);
        rgba[idx + 1] = Math.round(gSum / shapeHits);
        rgba[idx + 2] = Math.round(bSum / shapeHits);
        rgba[idx + 3] = Math.round((shapeHits / (S * S)) * 255);
      }
    }
  }
  return rgba;
}

// ── 组装 ICO ───────────────────────────────────────────────
const SPEC = [
  { size: 16, png: false },
  { size: 24, png: false },
  { size: 32, png: false },
  { size: 48, png: false },
  { size: 64, png: false },
  { size: 128, png: true },
  { size: 256, png: true },
];

const images = SPEC.map(({ size, png }) => {
  const rgba = render(size);
  return { size, data: png ? encodePNG(size, rgba) : bmpEntry(size, rgba) };
});

const header = Buffer.alloc(6);
header.writeUInt16LE(0, 0);
header.writeUInt16LE(1, 2); // ICO
header.writeUInt16LE(images.length, 4);

const dir = Buffer.alloc(16 * images.length);
let offset = 6 + dir.length;
images.forEach((img, i) => {
  const p = i * 16;
  dir.writeUInt8(img.size >= 256 ? 0 : img.size, p);
  dir.writeUInt8(img.size >= 256 ? 0 : img.size, p + 1);
  dir.writeUInt8(0, p + 2);
  dir.writeUInt8(0, p + 3);
  dir.writeUInt16LE(1, p + 4);   // planes
  dir.writeUInt16LE(32, p + 6);  // bpp
  dir.writeUInt32LE(img.data.length, p + 8);
  dir.writeUInt32LE(offset, p + 12);
  offset += img.data.length;
});

fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, Buffer.concat([header, dir, ...images.map((i) => i.data)]));
console.log("生成完成:", OUT, `(${SPEC.length} 个尺寸)`);
