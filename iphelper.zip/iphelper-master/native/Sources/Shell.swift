import Foundation

enum ShellError: LocalizedError {
    case launchFailed(String)
    case failed(String)

    var errorDescription: String? {
        switch self {
        case .launchFailed(let message): return message
        case .failed(let message): return message
        }
    }
}

enum Shell {
    /// 执行系统命令并返回 stdout（失败时抛出 stderr）
    @discardableResult
    static func run(_ launchPath: String, _ arguments: [String] = []) throws -> String {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: launchPath)
        process.arguments = arguments

        let outPipe = Pipe()
        let errPipe = Pipe()
        process.standardOutput = outPipe
        process.standardError = errPipe

        do {
            try process.run()
        } catch {
            throw ShellError.launchFailed("无法执行 \(launchPath)：\(error.localizedDescription)")
        }

        let outData = outPipe.fileHandleForReading.readDataToEndOfFile()
        let errData = errPipe.fileHandleForReading.readDataToEndOfFile()
        process.waitUntilExit()

        let stdout = String(data: outData, encoding: .utf8) ?? ""
        let stderr = String(data: errData, encoding: .utf8) ?? ""

        if process.terminationStatus != 0 {
            let message = stderr.trimmingCharacters(in: .whitespacesAndNewlines)
            throw ShellError.failed(message.isEmpty ? "命令执行失败：\(launchPath)" : message)
        }
        return stdout.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    /// 通过 AppleScript 以管理员权限执行（弹系统授权框，支持 Touch ID）
    @discardableResult
    static func sudo(_ command: String) throws -> String {
        let escaped = command
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")
        let script = "do shell script \"\(escaped)\" with administrator privileges"
        return try run("/usr/bin/osascript", ["-e", script])
    }
}
