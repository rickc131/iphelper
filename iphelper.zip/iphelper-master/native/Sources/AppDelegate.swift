import AppKit
import UserNotifications

final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate {
    private var statusItem: NSStatusItem!
    private let menu = NSMenu()
    private var savedConfigs: [SavedConfig] = []

    // MARK: - 生命周期

    func applicationDidFinishLaunching(_ notification: Notification) {
        _ = NSApp.setActivationPolicy(.accessory) // 纯菜单栏，不占 Dock
        guard ensureSingleInstance() else { return }

        ConfigStore.ensureDirs()
        requestNotificationPermission()
        setupStatusItem()
    }

    /// 菜单栏工具只应存在一个实例，避免出现多个角标
    private func ensureSingleInstance() -> Bool {
        guard let bundleID = Bundle.main.bundleIdentifier else { return true }
        let currentPID = ProcessInfo.processInfo.processIdentifier
        let others = NSRunningApplication
            .runningApplications(withBundleIdentifier: bundleID)
            .filter { $0.processIdentifier != currentPID }
        if !others.isEmpty {
            NSApp.terminate(nil)
            return false
        }
        return true
    }

    private func setupStatusItem() {
        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        if let button = item.button {
            let symbol = NSImage(systemSymbolName: "wifi", accessibilityDescription: "IPHelper")
            let fallbackPath = Bundle.main.path(forResource: "trayTemplate", ofType: "png")
            let image = symbol ?? (fallbackPath.flatMap { NSImage(contentsOfFile: $0) })
            image?.isTemplate = true
            button.image = image
            button.toolTip = "IPHelper · 点击选择要切换的网络配置"
        }
        menu.autoenablesItems = false
        menu.delegate = self
        item.menu = menu
        statusItem = item
    }

    // MARK: - 菜单构建（每次展开都重新读取，保证最新）

    func menuNeedsUpdate(_ menu: NSMenu) {
        menu.removeAllItems()
        savedConfigs = ConfigStore.list()

        let header = NSMenuItem(title: "IPHelper", action: nil, keyEquivalent: "")
        header.isEnabled = false
        menu.addItem(header)

        if savedConfigs.isEmpty {
            let empty = NSMenuItem(title: "（暂无已保存配置）", action: nil, keyEquivalent: "")
            empty.isEnabled = false
            menu.addItem(empty)
        } else {
            for config in savedConfigs {
                let tag = config.record.mode == "dhcp" ? "DHCP" : "静态"
                let item = NSMenuItem(
                    title: "\(config.record.name)（\(tag)）",
                    action: #selector(applyConfig(_:)),
                    keyEquivalent: ""
                )
                item.target = self
                item.representedObject = config
                menu.addItem(item)
            }
        }

        menu.addItem(.separator())

        let saveItem = NSMenuItem(title: "保存当前配置…", action: #selector(saveCurrentConfig), keyEquivalent: "")
        saveItem.target = self
        menu.addItem(saveItem)

        addDHCPSubmenu(to: menu)

        if !savedConfigs.isEmpty {
            addDeleteSubmenu(to: menu)
        }

        menu.addItem(.separator())

        let openConfigs = NSMenuItem(title: "打开配置目录", action: #selector(openConfigsDir), keyEquivalent: "")
        openConfigs.target = self
        menu.addItem(openConfigs)

        let openLog = NSMenuItem(title: "查看日志", action: #selector(openLog), keyEquivalent: "")
        openLog.target = self
        menu.addItem(openLog)

        let login = NSMenuItem(title: "开机自启动", action: #selector(toggleLoginItem), keyEquivalent: "")
        login.target = self
        login.state = LoginItem.isEnabled ? .on : .off
        menu.addItem(login)

        menu.addItem(.separator())

        let quit = NSMenuItem(title: "退出 IPHelper", action: #selector(quit), keyEquivalent: "q")
        quit.target = self
        menu.addItem(quit)
    }

    private func addDHCPSubmenu(to menu: NSMenu) {
        let interfaces = Network.interfaces()
        guard !interfaces.isEmpty else {
            let item = NSMenuItem(title: "恢复 DHCP（未找到网卡）", action: nil, keyEquivalent: "")
            item.isEnabled = false
            menu.addItem(item)
            return
        }
        let parent = NSMenuItem(title: "恢复 DHCP", action: nil, keyEquivalent: "")
        let submenu = NSMenu()
        submenu.autoenablesItems = false
        for iface in interfaces {
            let item = NSMenuItem(
                title: "\(iface.displayName)（\(iface.device)）",
                action: #selector(switchToDHCP(_:)),
                keyEquivalent: ""
            )
            item.target = self
            item.representedObject = iface.device
            submenu.addItem(item)
        }
        parent.submenu = submenu
        menu.addItem(parent)
    }

    private func addDeleteSubmenu(to menu: NSMenu) {
        let parent = NSMenuItem(title: "删除配置", action: nil, keyEquivalent: "")
        let submenu = NSMenu()
        submenu.autoenablesItems = false
        for config in savedConfigs {
            let item = NSMenuItem(
                title: config.record.name,
                action: #selector(deleteConfig(_:)),
                keyEquivalent: ""
            )
            item.target = self
            item.representedObject = config
            submenu.addItem(item)
        }
        parent.submenu = submenu
        menu.addItem(parent)
    }

    // MARK: - 动作

    @objc private func applyConfig(_ sender: NSMenuItem) {
        guard let config = sender.representedObject as? SavedConfig else { return }
        let name = config.record.name
        statusItem.button?.toolTip = "IPHelper · 正在应用「\(name)」…"

        DispatchQueue.global().async {
            let outcome: Result<Void, Error>
            do {
                try Network.apply(config.record)
                outcome = .success(())
            } catch {
                outcome = .failure(error)
            }

            DispatchQueue.main.async {
                switch outcome {
                case .success:
                    self.statusItem.button?.toolTip = "IPHelper · 当前：\(name)"
                    self.notify(title: "IPHelper", body: "已应用配置「\(name)」")
                case .failure(let error):
                    if self.isUserCanceled(error) {
                        self.statusItem.button?.toolTip = "IPHelper"
                    } else {
                        self.presentError(title: "未能应用配置「\(name)」", error: error)
                    }
                }
            }
        }
    }

    @objc private func switchToDHCP(_ sender: NSMenuItem) {
        guard let device = sender.representedObject as? String else { return }
        statusItem.button?.toolTip = "IPHelper · 正在切换 \(device) 为 DHCP…"

        DispatchQueue.global().async {
            let outcome: Result<Void, Error>
            do {
                try Network.switchToDHCP(device: device)
                outcome = .success(())
            } catch {
                outcome = .failure(error)
            }

            DispatchQueue.main.async {
                switch outcome {
                case .success:
                    self.statusItem.button?.toolTip = "IPHelper"
                    self.notify(title: "IPHelper", body: "\(device) 已切换为 DHCP")
                case .failure(let error):
                    if self.isUserCanceled(error) {
                        self.statusItem.button?.toolTip = "IPHelper"
                    } else {
                        self.presentError(title: "切换 DHCP 失败", error: error)
                    }
                }
            }
        }
    }

    @objc private func saveCurrentConfig() {
        if SavePanelController().run() {
            notify(title: "IPHelper", body: "当前配置已保存")
        }
    }

    @objc private func deleteConfig(_ sender: NSMenuItem) {
        guard let config = sender.representedObject as? SavedConfig else { return }

        let alert = NSAlert()
        alert.messageText = "删除配置「\(config.record.name)」？"
        alert.informativeText = "此操作不可撤销。"
        alert.addButton(withTitle: "删除")
        alert.addButton(withTitle: "取消")
        NSApp.activate(ignoringOtherApps: true)
        guard alert.runModal() == .alertFirstButtonReturn else { return }

        do {
            try ConfigStore.delete(config)
        } catch {
            presentError(title: "删除配置失败", error: error)
        }
    }

    @objc private func openConfigsDir() {
        ConfigStore.ensureDirs()
        _ = NSWorkspace.shared.open(ConfigStore.configsDir)
    }

    @objc private func openLog() {
        if !FileManager.default.fileExists(atPath: ConfigStore.logFile.path) {
            ConfigStore.appendLog("IPHelper 启动")
        }
        _ = NSWorkspace.shared.open(ConfigStore.logFile)
    }

    @objc private func toggleLoginItem() {
        do {
            try LoginItem.setEnabled(!LoginItem.isEnabled)
        } catch {
            presentError(title: "设置开机自启动失败", error: error)
        }
    }

    @objc private func quit() {
        NSApp.terminate(nil)
    }

    // MARK: - 通知与提示

    private func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }

    private func notify(title: String, body: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
    }

    private func isUserCanceled(_ error: Error) -> Bool {
        let message = error.localizedDescription
        return message.contains("-128") || message.localizedCaseInsensitiveContains("cancel")
            || message.contains("已取消")
    }

    private func presentError(title: String, error: Error) {
        let alert = NSAlert()
        alert.alertStyle = .warning
        alert.messageText = title
        alert.informativeText = error.localizedDescription
        alert.addButton(withTitle: "好")
        NSApp.activate(ignoringOtherApps: true)
        alert.runModal()
    }
}
