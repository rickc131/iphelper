import AppKit

/// 「保存当前配置」弹窗：选择网卡 + 实时抓取当前参数 + 命名保存
final class SavePanelController: NSObject {
    private var interfaces: [NetworkInterface] = []
    private var current: CurrentConfig?
    private var popup: NSPopUpButton?
    private var nameField: NSTextField?
    private var infoLabel: NSTextField?

    /// 返回 true 表示已成功保存
    func run() -> Bool {
        interfaces = Network.interfaces()
        guard !interfaces.isEmpty else {
            presentError("未检测到可用网卡")
            return false
        }

        let alert = NSAlert()
        alert.messageText = "保存当前配置"
        alert.informativeText = "选择网卡并命名，当前网络参数会一并保存到存档列表。"
        alert.addButton(withTitle: "保存")
        alert.addButton(withTitle: "取消")

        let accessory = NSView(frame: NSRect(x: 0, y: 0, width: 380, height: 190))

        let ifaceLabel = NSTextField(labelWithString: "网卡")
        ifaceLabel.frame = NSRect(x: 0, y: 162, width: 44, height: 20)

        let popup = NSPopUpButton(frame: NSRect(x: 50, y: 158, width: 330, height: 26), pullsDown: false)
        for iface in interfaces {
            popup.addItem(withTitle: "\(iface.device) — \(iface.displayName)")
        }
        popup.target = self
        popup.action = #selector(interfaceChanged(_:))

        let info = NSTextField(labelWithString: "读取中…")
        info.frame = NSRect(x: 0, y: 92, width: 380, height: 62)
        info.font = NSFont.monospacedSystemFont(ofSize: 11, weight: .regular)
        info.textColor = .secondaryLabelColor
        info.maximumNumberOfLines = 4

        let nameLabel = NSTextField(labelWithString: "名称")
        nameLabel.frame = NSRect(x: 0, y: 58, width: 44, height: 20)

        let nameField = NSTextField(frame: NSRect(x: 50, y: 54, width: 330, height: 24))
        nameField.placeholderString = "如：办公室 Wi-Fi"

        let hint = NSTextField(labelWithString: "保存到 configs 存档目录；同名不会覆盖")
        hint.frame = NSRect(x: 0, y: 26, width: 380, height: 18)
        hint.font = NSFont.systemFont(ofSize: 10)
        hint.textColor = .tertiaryLabelColor

        accessory.addSubview(ifaceLabel)
        accessory.addSubview(popup)
        accessory.addSubview(info)
        accessory.addSubview(nameLabel)
        accessory.addSubview(nameField)
        accessory.addSubview(hint)
        alert.accessoryView = accessory

        self.popup = popup
        self.nameField = nameField
        self.infoLabel = info

        // 默认选中当前有 IP 的网卡，并在后台读取参数
        DispatchQueue.global().async {
            let index = self.findActiveInterfaceIndex()
            DispatchQueue.main.async {
                popup.selectItem(at: index)
                self.refreshInfo()
            }
        }

        NSApp.activate(ignoringOtherApps: true)
        while true {
            if alert.runModal() != .alertFirstButtonReturn { return false }
            guard let record = buildRecord() else { continue }
            do {
                try ConfigStore.save(record)
                return true
            } catch {
                presentError(error.localizedDescription)
            }
        }
    }

    // MARK: - 交互

    @objc private func interfaceChanged(_ sender: NSPopUpButton) {
        refreshInfo()
    }

    private func refreshInfo() {
        guard let popup, let infoLabel else { return }
        let index = popup.indexOfSelectedItem
        guard index >= 0, index < interfaces.count else { return }

        let iface = interfaces[index]
        infoLabel.stringValue = "读取中…"
        current = nil

        DispatchQueue.global().async {
            let config = Network.currentConfig(device: iface.device)
            DispatchQueue.main.async {
                self.current = config
                infoLabel.stringValue = Self.describe(config)
            }
        }
    }

    private func findActiveInterfaceIndex() -> Int {
        for (index, iface) in interfaces.enumerated() where Network.currentConfig(device: iface.device).ip != nil {
            return index
        }
        return 0
    }

    private static func describe(_ config: CurrentConfig) -> String {
        let mode = config.ip == nil ? "DHCP" : "静态"
        let dns = config.dns.isEmpty ? "自动" : config.dns.joined(separator: ", ")
        return """
        模式: \(mode)
        IP: \(config.ip ?? "—") / \(config.netmask ?? "—")
        网关: \(config.gateway ?? "—")
        DNS: \(dns)
        """
    }

    // MARK: - 保存

    private func buildRecord() -> ConfigRecord? {
        guard let popup, let nameField else { return nil }

        let name = nameField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else {
            presentError("请填写配置名称")
            return nil
        }
        guard let config = current else {
            presentError("正在读取当前网络信息，请稍候重试")
            return nil
        }
        let index = popup.indexOfSelectedItem
        guard index >= 0, index < interfaces.count else { return nil }
        let iface = interfaces[index]

        if let ip = config.ip, !Network.isValidIPv4(ip) {
            presentError("IP 地址格式无效：\(ip)")
            return nil
        }
        if let mask = config.netmask, !mask.isEmpty, !Network.isValidIPv4(mask) {
            presentError("子网掩码格式无效：\(mask)")
            return nil
        }
        if let gateway = config.gateway, !gateway.isEmpty, !Network.isValidIPv4(gateway) {
            presentError("网关地址格式无效：\(gateway)")
            return nil
        }
        for dns in config.dns where !Network.isValidIPv4(dns) {
            presentError("DNS 地址格式无效：\(dns)")
            return nil
        }

        return ConfigRecord(
            name: name,
            interface: iface.device,
            serviceName: iface.displayName,
            mode: config.mode,
            ip: config.ip ?? "",
            netmask: config.netmask ?? "",
            gateway: config.gateway ?? "",
            dns: config.dns
        )
    }

    // MARK: - 提示

    private func presentError(_ message: String) {
        let alert = NSAlert()
        alert.alertStyle = .warning
        alert.messageText = message
        alert.addButton(withTitle: "好")
        NSApp.activate(ignoringOtherApps: true)
        alert.runModal()
    }
}
