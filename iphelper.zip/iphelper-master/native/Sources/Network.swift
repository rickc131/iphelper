import Foundation

struct NetworkInterface {
    let device: String       // en0
    let displayName: String  // Wi-Fi
}

struct CurrentConfig {
    var mode: String         // static / dhcp
    var ip: String?
    var netmask: String?
    var gateway: String?
    var dns: [String]
}

enum Network {
    // MARK: - 网卡与服务名

    /// 物理网卡列表（en*，排除虚拟接口）；与旧版 Electron 过滤规则一致
    static func interfaces() -> [NetworkInterface] {
        guard let raw = try? Shell.run("/usr/sbin/networksetup", ["-listallhardwareports"]) else { return [] }

        var all: [NetworkInterface] = []
        for block in raw.components(separatedBy: "\n\n") {
            guard let port = firstMatch(block, "^Hardware Port:\\s*(.+)$"),
                  let device = firstMatch(block, "^Device:\\s*(.+)$") else { continue }
            all.append(NetworkInterface(device: device, displayName: port))
        }

        let physical = all.filter { $0.device.range(of: "^en\\d+$", options: .regularExpression) != nil }
        return physical.isEmpty ? all : physical
    }

    /// 设备名（en0）→ 网络服务名（Wi-Fi）
    static func serviceName(for device: String) -> String? {
        if let raw = try? Shell.run("/usr/sbin/networksetup", ["-listallhardwareports"]) {
            for block in raw.components(separatedBy: "\n\n") {
                guard firstMatch(block, "^Device:\\s*(.+)$") == device,
                      let port = firstMatch(block, "^Hardware Port:\\s*(.+)$") else { continue }
                // 防御：确保返回的是服务名而非设备名
                if port.range(of: "^en\\d+$", options: .regularExpression) == nil {
                    return port
                }
            }
        }

        // 回退：listnetworkserviceorder
        if let raw = try? Shell.run("/usr/sbin/networksetup", ["-listnetworkserviceorder"]) {
            let lines = raw.components(separatedBy: "\n")
            for (index, line) in lines.enumerated() {
                guard let service = firstMatch(line, "^\\(\\d+\\)\\s+(.+)$") else { continue }
                let description = lines[index..<min(index + 3, lines.count)].joined(separator: " ")
                if let deviceName = firstMatch(description, "Device:\\s*(\\S+)"), deviceName == device {
                    return service
                }
            }
        }
        return nil
    }

    // MARK: - 读取当前配置

    static func currentConfig(device: String) -> CurrentConfig {
        let service = serviceName(for: device)

        var ip: String?
        var netmask: String?
        if let raw = try? Shell.run("/sbin/ifconfig", [device]),
           let groups = firstMatchGroups(raw, "inet\\s+(\\d+\\.\\d+\\.\\d+\\.\\d+)\\s+netmask\\s+(0x[0-9a-fA-F]+)"),
           groups.count >= 2 {
            ip = groups[0]
            netmask = hexToNetmask(groups[1])
        }

        let gateway = service.flatMap { serviceRouter($0) } ?? defaultGateway()

        var dns: [String] = []
        if let service,
           let raw = try? Shell.run("/usr/sbin/networksetup", ["-getdnsservers", service]),
           !raw.contains("There aren't any DNS Servers") {
            dns = raw
                .components(separatedBy: "\n")
                .map { $0.trimmingCharacters(in: .whitespaces) }
                .filter { isValidIPv4($0) }
        }

        return CurrentConfig(
            mode: ip == nil ? "dhcp" : "static",
            ip: ip,
            netmask: netmask,
            gateway: gateway,
            dns: dns
        )
    }

    /// 读取指定服务自身的 Router（多网卡场景下比系统默认路由准确）
    static func serviceRouter(_ service: String) -> String? {
        guard let raw = try? Shell.run("/usr/sbin/networksetup", ["-getinfo", service]) else { return nil }
        return firstMatch(raw, "^Router:\\s*(\\d+\\.\\d+\\.\\d+\\.\\d+)$")
    }

    static func defaultGateway() -> String? {
        guard let raw = try? Shell.run("/usr/sbin/netstat", ["-rn", "-f", "inet"]) else { return nil }
        return firstMatch(raw, "^default\\s+(\\d+\\.\\d+\\.\\d+\\.\\d+)$")
    }

    // MARK: - 应用配置

    /// 应用静态配置：IP + 掩码 + 网关 + DNS 合并为一次提权调用（只弹一次授权）
    static func apply(_ record: ConfigRecord) throws {
        let device = record.interface
        guard let service = record.serviceName ?? serviceName(for: device) else {
            throw ShellError.failed("无法找到网卡「\(device)」对应的网络服务名，请在菜单中重新保存该配置。")
        }

        // 网关为空时保留该网卡自身网关，避免 -setmanual 传空串清空网关
        var gateway = record.gateway ?? ""
        if gateway.isEmpty {
            gateway = serviceRouter(service) ?? defaultGateway() ?? ""
        }

        var command = "networksetup -setmanual \"\(service)\" \"\(record.ip ?? "")\" \"\(record.netmask ?? "")\" \"\(gateway)\""
        if let dns = record.dns, !dns.isEmpty {
            command += " && networksetup -setdnsservers \"\(service)\" " + dns.map { "\"\($0)\"" }.joined(separator: " ")
        } else {
            command += " && networksetup -setdnsservers \"\(service)\" Empty"
        }

        _ = try Shell.sudo(command)
        ConfigStore.appendLog("设置静态IP: \(service)(\(device)) → \(record.ip ?? "")/\(record.netmask ?? "") gw=\(gateway)")
    }

    /// 恢复 DHCP：切换 + 清空 DNS 合并为一次提权调用
    static func switchToDHCP(device: String) throws {
        guard let service = serviceName(for: device) else {
            throw ShellError.failed("无法找到网卡「\(device)」对应的网络服务名")
        }
        _ = try Shell.sudo("networksetup -setdhcp \"\(service)\" && networksetup -setdnsservers \"\(service)\" Empty")
        ConfigStore.appendLog("切换DHCP: \(service)(\(device))")
    }

    // MARK: - 工具

    static func isValidIPv4(_ value: String) -> Bool {
        let pattern = "^(?:(?:25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(?:25[0-5]|2[0-4]\\d|[01]?\\d\\d?)$"
        return value.range(of: pattern, options: .regularExpression) != nil
    }

    static func hexToNetmask(_ hex: String) -> String? {
        let clean = hex.hasPrefix("0x") ? String(hex.dropFirst(2)) : hex
        guard let value = UInt32(clean, radix: 16) else { return nil }
        return "\((value >> 24) & 0xff).\((value >> 16) & 0xff).\((value >> 8) & 0xff).\(value & 0xff)"
    }

    static func firstMatch(_ text: String, _ pattern: String) -> String? {
        firstMatchGroups(text, pattern)?.first
    }

    static func firstMatchGroups(_ text: String, _ pattern: String) -> [String]? {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.anchorsMatchLines]) else { return nil }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        guard let match = regex.firstMatch(in: text, options: [], range: range) else { return nil }

        var groups: [String] = []
        for index in 1..<match.numberOfRanges {
            if let groupRange = Range(match.range(at: index), in: text) {
                groups.append(String(text[groupRange]))
            }
        }
        return groups
    }
}
