import Foundation

/// 与旧版 Electron 完全一致的配置结构（可直接复用历史 configs/*.json）
struct ConfigRecord: Codable {
    var name: String
    var interface: String
    var serviceName: String?
    var mode: String?
    var ip: String?
    var netmask: String?
    var gateway: String?
    var dns: [String]?
}

struct SavedConfig {
    let record: ConfigRecord
    let fileURL: URL
}

enum ConfigStore {
    /// 沿用旧版路径（~/Library/Application Support/iphelper），历史配置与日志无缝继承
    static var appSupportDir: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        return base.appendingPathComponent("iphelper", isDirectory: true)
    }

    static var configsDir: URL {
        appSupportDir.appendingPathComponent("configs", isDirectory: true)
    }

    static var logFile: URL {
        appSupportDir.appendingPathComponent("log.txt")
    }

    static func ensureDirs() {
        try? FileManager.default.createDirectory(at: configsDir, withIntermediateDirectories: true)
    }

    static func list() -> [SavedConfig] {
        ensureDirs()
        let files = (try? FileManager.default.contentsOfDirectory(
            at: configsDir,
            includingPropertiesForKeys: nil
        )) ?? []

        var result: [SavedConfig] = []
        for file in files where file.pathExtension.lowercased() == "json" {
            guard let data = try? Data(contentsOf: file),
                  let record = try? JSONDecoder().decode(ConfigRecord.self, from: data) else { continue }
            result.append(SavedConfig(record: record, fileURL: file))
        }
        return result.sorted { $0.record.name.localizedStandardCompare($1.record.name) == .orderedAscending }
    }

    /// 与旧版 safeName 等价：过滤文件系统非法字符
    static func safeName(_ raw: String) -> String {
        var invalid = CharacterSet(charactersIn: "<>:\"/\\|?*")
        invalid.formUnion(.controlCharacters)
        let cleaned = raw
            .components(separatedBy: invalid)
            .joined(separator: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned.isEmpty ? "unnamed" : cleaned
    }

    @discardableResult
    static func save(_ record: ConfigRecord) throws -> URL {
        ensureDirs()
        let fileName = safeName(record.name)
        let url = configsDir.appendingPathComponent("\(fileName).json")
        if FileManager.default.fileExists(atPath: url.path) {
            throw ShellError.failed("配置「\(fileName)」已存在，请使用其他名称")
        }
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .withoutEscapingSlashes]
        try encoder.encode(record).write(to: url, options: .atomic)
        appendLog("保存配置: \(fileName)")
        return url
    }

    static func delete(_ saved: SavedConfig) throws {
        try FileManager.default.removeItem(at: saved.fileURL)
        appendLog("删除配置: \(saved.record.name)")
    }

    /// 与旧版日志格式保持一致：[yyyy-MM-dd HH:mm:ss] 内容
    static func appendLog(_ entry: String) {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let line = "[\(formatter.string(from: Date()))] \(entry)\n"
        ensureDirs()
        let data = Data(line.utf8)
        if let handle = try? FileHandle(forWritingTo: logFile) {
            handle.seekToEndOfFile()
            handle.write(data)
            try? handle.close()
        } else {
            try? data.write(to: logFile)
        }
    }
}
