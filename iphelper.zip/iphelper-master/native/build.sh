#!/bin/bash
# 构建原生版 IPHelper.app（纯菜单栏，无 Electron）
set -euo pipefail
cd "$(dirname "$0")"

APP_NAME="IPHelper"
BUNDLE_ID="com.iphelper.app"
VERSION="2.0.0"
BUNDLE_VERSION="2"
MIN_MACOS="13.0"

ARCH="${ARCH:-$(uname -m)}"
case "$ARCH" in
  arm64)  TARGET="arm64-apple-macos${MIN_MACOS}" ;;
  x86_64) TARGET="x86_64-apple-macos${MIN_MACOS}" ;;
  *)      TARGET="${ARCH}-apple-macos${MIN_MACOS}" ;;
esac

OUT_DIR="build"
APP_DIR="${OUT_DIR}/${APP_NAME}.app"

echo "==> 清理旧产物"
rm -rf "$APP_DIR"
mkdir -p "$APP_DIR/Contents/MacOS" "$APP_DIR/Contents/Resources"

echo "==> 编译 Swift 源码（${TARGET}）"
swiftc \
  -O -whole-module-optimization -swift-version 5 \
  -target "$TARGET" \
  -framework AppKit -framework ServiceManagement -framework UserNotifications \
  -o "$APP_DIR/Contents/MacOS/${APP_NAME}" \
  Sources/*.swift

echo "==> 精简二进制符号"
strip -x "$APP_DIR/Contents/MacOS/${APP_NAME}" 2>/dev/null || true

echo "==> 复制资源"
for f in Resources/*; do
  [ -e "$f" ] && cp "$f" "$APP_DIR/Contents/Resources/"
done

echo "==> 写入 Info.plist"
cat > "$APP_DIR/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>${APP_NAME}</string>
  <key>CFBundleDisplayName</key><string>${APP_NAME}</string>
  <key>CFBundleIdentifier</key><string>${BUNDLE_ID}</string>
  <key>CFBundleExecutable</key><string>${APP_NAME}</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundleShortVersionString</key><string>${VERSION}</string>
  <key>CFBundleVersion</key><string>${BUNDLE_VERSION}</string>
  <key>LSMinimumSystemVersion</key><string>${MIN_MACOS}</string>
  <key>LSUIElement</key><true/>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSHumanReadableCopyright</key><string>Copyright © 2026 skiperchen</string>
</dict>
</plist>
PLIST

printf 'APPL????' > "$APP_DIR/Contents/PkgInfo"

echo "==> ad-hoc 签名"
codesign --force --sign - "$APP_DIR" >/dev/null 2>&1 || echo "  （签名跳过）"

echo "==> 完成：${APP_DIR}"
du -sh "$APP_DIR"
