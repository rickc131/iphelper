"use strict";
// 生成原生版 IPHelper 的应用图标（蓝色圆角底 + 白色 WiFi 标识）并导出 AppIcon.icns
// 用法：node native/tools/make_appicon.js
const zlib = require("zlib");
const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const OUT_DIR = path.join(__dirname, "..", "Resources");
const TMP_ICONSET = path.join(require("os").tmpdir(), "IPHelper-AppIcon.iconset");

// ── PNG 编码 ───────────────────────────────────────────────
function crc32(buf) {
  let table = crc32.table;
  if (!table) {
    table = crc32.table = new Int32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      table[n] = c;
    }
  }
  let crc = -1;
  for (let i = 0; i < buf.length; i++) crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
  return (crc ^ -1) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, "ascii");
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function encodePNG(width, height, rgba) {
  const sig = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (width * 4 + 1)] = 0;
    rgba.copy(raw, y * (width * 4 + 1) + 1, y * width * 4, (y + 1) * width * 4);
  }
  return Buffer.concat([
    sig,
    chunk("IHDR", ihdr),
    chunk("IDAT", zlib.deflateSync(raw, { level: 9 })),
    chunk("IEND", Buffer.alloc(0)),
  ]);
}

// ── 形状 ───────────────────────────────────────────────────
// 圆角矩形有向距离（<=0 表示在内部）
function insideRoundedRect(px, py, x0, y0, w, h, radius) {
  const halfW = w / 2, halfH = h / 2;
  const qx = Math.abs(px - (x0 + halfW)) - (halfW - radius);
  const qy = Math.abs(py - (y0 + halfH)) - (halfH - radius);
  const d = Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - radius;
  return d <= 0;
}

// WiFi 字形（内容盒子归一化坐标）：圆点 + 上方三道半圆信号弧
function insideGlyph(nx, ny) {
  const cx = 0.5, cy = 0.665;
  const radii = [0.155, 0.275, 0.395];
  const halfW = 0.042;
  const dotR = 0.075;

  const dx = nx - cx, dy = ny - cy;
  const d = Math.hypot(dx, dy);
  if (d <= dotR) return true;
  if (ny < cy) {
    for (const r of radii) {
      if (d >= r - halfW && d <= r + halfW) return true;
    }
  }
  return false;
}

// 顶部 → 底部渐变（网络蓝）
const TOP = [62, 166, 255];
const BOTTOM = [6, 82, 190];

function renderIcon(size) {
  const S = 4;                       // 超采样
  const content = size * 0.804;      // macOS 风格留白
  const offset = (size - content) / 2;
  const radius = content * 0.2237;
  const rgba = Buffer.alloc(size * size * 4);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let shapeHits = 0, glyphHits = 0, rSum = 0, gSum = 0, bSum = 0;

      for (let sy = 0; sy < S; sy++) {
        for (let sx = 0; sx < S; sx++) {
          const px = x + (sx + 0.5) / S;
          const py = y + (sy + 0.5) / S;
          if (!insideRoundedRect(px, py, offset, offset, content, content, radius)) continue;
          shapeHits++;

          const nx = (px - offset) / content;
          const ny = (py - offset) / content;
          if (insideGlyph(nx, ny)) {
            glyphHits++;
            rSum += 255; gSum += 255; bSum += 255;
          } else {
            const t = Math.max(0, Math.min(1, ny));
            rSum += TOP[0] + (BOTTOM[0] - TOP[0]) * t;
            gSum += TOP[1] + (BOTTOM[1] - TOP[1]) * t;
            bSum += TOP[2] + (BOTTOM[2] - TOP[2]) * t;
          }
        }
      }

      const total = S * S;
      const idx = (y * size + x) * 4;
      if (shapeHits === 0) {
        rgba[idx] = rgba[idx + 1] = rgba[idx + 2] = rgba[idx + 3] = 0;
      } else {
        rgba[idx] = Math.round(rSum / shapeHits);
        rgba[idx + 1] = Math.round(gSum / shapeHits);
        rgba[idx + 2] = Math.round(bSum / shapeHits);
        rgba[idx + 3] = Math.round((shapeHits / total) * 255);
      }
    }
  }
  return encodePNG(size, size, rgba);
}

// ── 输出 iconset → icns ────────────────────────────────────
fs.rmSync(TMP_ICONSET, { recursive: true, force: true });
fs.mkdirSync(TMP_ICONSET, { recursive: true });

const entries = [
  [16, "icon_16x16.png"],
  [32, "icon_16x16@2x.png"],
  [32, "icon_32x32.png"],
  [64, "icon_32x32@2x.png"],
  [128, "icon_128x128.png"],
  [256, "icon_128x128@2x.png"],
  [256, "icon_256x256.png"],
  [512, "icon_256x256@2x.png"],
  [512, "icon_512x512.png"],
  [1024, "icon_512x512@2x.png"],
];

for (const [size, name] of entries) {
  fs.writeFileSync(path.join(TMP_ICONSET, name), renderIcon(size));
}

fs.mkdirSync(OUT_DIR, { recursive: true });
const icnsPath = path.join(OUT_DIR, "AppIcon.icns");
execFileSync("iconutil", ["-c", "icns", TMP_ICONSET, "-o", icnsPath]);
fs.rmSync(TMP_ICONSET, { recursive: true, force: true });

console.log("生成完成:", icnsPath);
