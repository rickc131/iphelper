"use strict";

const {
  app,
  BrowserWindow,
  ipcMain,
  Tray,
  Menu,
  nativeImage,
  Notification,
  dialog,
} = require("electron");
const path = require("path");
const fs = require("fs/promises");
const { existsSync, mkdirSync, readFileSync } = require("fs");
const { execFile } = require("child_process");

// ──────────────────────────────────────────────
// 路径常量
// ──────────────────────────────────────────────
let APP_DIR, CONFIGS_DIR, LOG_FILE;
function initPaths() {
  try {
    APP_DIR = app.getPath("userData");
  } catch (_) {
    APP_DIR = path.join(app.getPath("appData"), "IPHelper");
  }
  CONFIGS_DIR = path.join(APP_DIR, "configs");
  LOG_FILE = path.join(APP_DIR, "log.txt");
}

// ──────────────────────────────────────────────
// 全局状态 / 跨窗口通知
// ──────────────────────────────────────────────
let tray = null;      // 菜单栏角标
let mainWindow = null; // 主界面（按需创建）
let saveDlg = null;    // 保存当前配置弹窗
let quitting = false;  // 是否正在退出

/** 向所有渲染窗口广播事件（不含 tray） */
function broadcastToRenderers(channel, ...args) {
  for (const win of BrowserWindow.getAllWindows()) {
    if (!win.isDestroyed()) win.webContents.send(channel, ...args);
  }
}

/** 系统通知（未授权时静默失败，不影响主流程） */
function notify(title, body) {
  try {
    if (Notification.isSupported()) new Notification({ title, body }).show();
  } catch (_) {
    // ignore
  }
}

/** 是否为「用户取消授权/拒绝」类错误（静默处理，不弹错误框） */
function isUserCanceled(msg) {
  return /canceled|cancelled|-128|用户已取消|已取消/i.test(msg || "");
}

/** 渲染层请求关闭自身窗口（主界面关闭时走 hide 逻辑） */
ipcMain.on("close-current-window", (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (win) win.close();
});

// ──────────────────────────────────────────────
// 工具函数
// ──────────────────────────────────────────────

/** 用 execFile 执行命令，返回 stdout */
function execPromise(cmd, args = [], opts = {}) {
  return new Promise((resolve, reject) => {
    execFile(cmd, args, { timeout: 30000, ...opts }, (err, stdout, stderr) => {
      if (err) return reject(new Error(stderr || err.message));
      resolve(stdout.trim());
    });
  });
}

/** 通过 osascript + administrator privileges 执行写入命令 */
async function sudoExec(command) {
  const escaped = command.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  const script = `do shell script "${escaped}" with administrator privileges`;
  return execPromise("osascript", ["-e", script]);
}

/** 追加日志 */
async function appendLog(entry) {
  const ts = new Date().toISOString().replace("T", " ").slice(0, 19);
  const line = `[${ts}] ${entry}\n`;
  try {
    await fs.appendFile(LOG_FILE, line, "utf-8");
  } catch (_) {
    // 日志写入失败不阻塞主流程
  }
}

/** 确保 configs 目录存在 */
async function ensureConfigsDir() {
  try {
    await fs.mkdir(CONFIGS_DIR, { recursive: true });
  } catch (_) {
    // 已存在则忽略
  }
}

/** IP 格式校验 */
function isValidIP(ip) {
  return /^(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$/.test(ip);
}

/** 安全化配置文件名 */
function safeName(name) {
  return name.replace(/[<>:"/\\|?*\x00-\x1f]/g, "_").trim() || "unnamed";
}

// ──────────────────────────────────────────────
// 系统命令层 ─ 获取网络信息
// ──────────────────────────────────────────────

/** 解析 networksetup -listallhardwareports 输出 */
function parseHardwarePorts(raw) {
  const interfaces = [];
  const blocks = raw.split(/\n\n+/);
  for (const block of blocks) {
    const portMatch = block.match(/^Hardware Port:\s*(.+)$/m);
    const devMatch = block.match(/^Device:\s*(.+)$/m);
    if (portMatch && devMatch) {
      interfaces.push({
        name: devMatch[1],           // en0, en1 ...
        displayName: portMatch[1],   // Wi-Fi, Ethernet ...
      });
    }
  }
  return interfaces;
}

/** 按规则过滤：优先物理网卡（en* 开头），排除 lo0/bridge/vmnet/utun/llw/anpi/ap/awdl */
function filterPhysical(ifaces) {
  return ifaces.filter((iface) => {
    const n = iface.name;
    // 允许 en* 开头的物理网卡，同时排除已知虚拟接口
    return (
      /^en\d+$/.test(n) &&
      !/^(lo\d*|bridge\d*|gif\d*|stf\d*|vmnet\d*|utun\d*|llw\d*|anpi\d*|ap\d*|awdl\d*|pdp_ip\d*)$/.test(n)
    );
  });
}

// ──────────────────────────────────────────────
// IPC 通道注册
// ──────────────────────────────────────────────

/** get-interfaces: 获取物理网卡列表 */
async function fetchInterfaces() {
  const raw = await execPromise("networksetup", ["-listallhardwareports"]);
  const all = parseHardwarePorts(raw);
  const physical = filterPhysical(all);
  // 没有 en* 网卡时回退到全部（用户可能在虚拟机等环境）
  return physical.length > 0 ? physical : all;
}

ipcMain.handle("get-interfaces", async () => {
  try {
    const data = await fetchInterfaces();
    return { success: true, data };
  } catch (e) {
    return { success: false, error: `获取网卡列表失败: ${e.message}` };
  }
});

/** get-current-config: 抓取指定网卡的当前 IP/掩码/网关/DNS */
ipcMain.handle("get-current-config", async (_event, iface) => {
  try {
    if (!iface || typeof iface !== "string") {
      return { success: false, error: "请指定网卡名称" };
    }

    // 并行获取四类信息
    // networksetup 需要服务名（如 "Wi-Fi"），ifconfig 需要设备名（如 en0）
    const netName = await getServiceName(iface);
    const [ifconfigRaw, netstatRaw, dnsRaw] = await Promise.all([
      execPromise("ifconfig", [iface]).catch(() => ""),
      execPromise("netstat", ["-rn", "-f", "inet"]).catch(() => ""),
      netName ? execPromise("networksetup", ["-getdnsservers", netName]).catch(() => "") : Promise.resolve(""),
    ]);

    // 解析 IP 和掩码
    const inetMatch = ifconfigRaw.match(/inet\s+(\d+\.\d+\.\d+\.\d+)\s+netmask\s+(0x[0-9a-fA-F]+)/);
    const ip = inetMatch ? inetMatch[1] : null;
    const netmask = inetMatch ? hexToNetmask(inetMatch[2]) : null;

    // 解析默认网关
    const gwMatch = netstatRaw.match(/^default\s+(\d+\.\d+\.\d+\.\d+)/m);
    const gateway = gwMatch ? gwMatch[1] : null;

    // 解析 DNS
    let dns = [];
    if (dnsRaw && !dnsRaw.includes("There aren't any DNS Servers")) {
      dns = dnsRaw
        .split("\n")
        .map((s) => s.trim())
        .filter((s) => isValidIP(s));
    }

    return {
      success: true,
      data: { interface: iface, ip, netmask, gateway, dns, mode: ip ? "static" : "dhcp" },
    };
  } catch (e) {
    return { success: false, error: `抓取当前配置失败: ${e.message}` };
  }
});

/** get-dns: 读取指定网卡当前的 DNS 服务器 */
ipcMain.handle("get-dns", async (_event, iface) => {
  try {
    if (!iface || typeof iface !== "string") {
      return { success: false, error: "请指定网卡名称" };
    }
    const netName = await getServiceName(iface);
    if (!netName) {
      return { success: false, error: `无法找到网卡 "${iface}" 对应的网络服务名` };
    }
    const raw = await execPromise("networksetup", ["-getdnsservers", netName]).catch(() => "");
    const dns = raw
      .split("\n")
      .map((s) => s.trim())
      .filter((s) => isValidIP(s));
    await appendLog(`读取 DNS: ${netName}(${iface}) → ${dns.length ? dns.join(", ") : "无(自动)"}`);
    return { success: true, data: { interface: iface, serviceName: netName, dns } };
  } catch (e) {
    return { success: false, error: `读取 DNS 失败: ${e.message}` };
  }
});

/** set-dns: 写入指定网卡的 DNS 服务器（servers 为空数组 = 恢复自动/清空为 Empty） */
ipcMain.handle("set-dns", async (_event, iface, servers) => {
  try {
    if (!iface || typeof iface !== "string") {
      return { success: false, error: "请指定网卡名称" };
    }
    const netName = await getServiceName(iface);
    if (!netName) {
      return { success: false, error: `无法找到网卡 "${iface}" 对应的网络服务名` };
    }
    const rawList = Array.isArray(servers) ? servers.map((s) => String(s).trim()).filter(Boolean) : [];
    for (const s of rawList) {
      if (!isValidIP(s)) return { success: false, error: `DNS 地址无效: ${s}` };
    }
    const cmd =
      rawList.length === 0
        ? `networksetup -setdnsservers "${netName}" Empty`
        : `networksetup -setdnsservers "${netName}" ${rawList.map((d) => `"${d}"`).join(" ")}`;
    await sudoExec(cmd);
    await appendLog(`设置 DNS: ${netName}(${iface}) → ${rawList.length ? rawList.join(", ") : "Empty(自动)"}`);
    return { success: true, data: { interface: iface, dns: rawList.length ? rawList : null } };
  } catch (e) {
    await appendLog(`设置 DNS 失败: ${e.message}`);
    return { success: false, error: `设置 DNS 失败: ${e.message}` };
  }
});

/** save-config: 保存配置到 configs/xxx.json（拒绝覆盖） */
ipcMain.handle("save-config", async (_event, config) => {
  try {
    await ensureConfigsDir();

    if (!config || !config.name) {
      return { success: false, error: "配置名称不能为空" };
    }
    if (!config.interface) {
      return { success: false, error: "请选择网卡" };
    }

    const fname = safeName(config.name);
    const filePath = path.join(CONFIGS_DIR, `${fname}.json`);

    // 检查是否已存在
    try {
      await fs.access(filePath);
      return { success: false, error: `配置 "${fname}" 已存在，请使用其他名称` };
    } catch (_) {
      // 不存在，可以继续
    }

    // 校验 IP 格式
    if (config.ip && !isValidIP(config.ip)) {
      return { success: false, error: `IP 地址格式无效: ${config.ip}` };
    }
    if (config.netmask && !isValidIP(config.netmask)) {
      return { success: false, error: `子网掩码格式无效: ${config.netmask}` };
    }
    if (config.gateway && !isValidIP(config.gateway)) {
      return { success: false, error: `网关地址格式无效: ${config.gateway}` };
    }

    // 校验 DNS
    if (config.dns && Array.isArray(config.dns)) {
      for (const d of config.dns) {
        if (!isValidIP(d)) {
          return { success: false, error: `DNS 地址格式无效: ${d}` };
        }
      }
    }

    const record = {
      name: config.name,
      interface: config.interface,
      serviceName: config.serviceName || await getServiceName(config.interface),
      mode: config.mode || "static",
      ip: config.ip || "",
      netmask: config.netmask || "",
      gateway: config.gateway || "",
      dns: config.dns || [],
    };

    await fs.writeFile(filePath, JSON.stringify(record, null, 2), "utf-8");
    await appendLog(`保存配置: ${fname}`);
    broadcastToRenderers("configs-changed");
    return { success: true, data: record };
  } catch (e) {
    return { success: false, error: `保存配置失败: ${e.message}` };
  }
});

/** list-configs: 读取 configs 目录下全部配置记录 */
async function readAllConfigs() {
  await ensureConfigsDir();
  const files = await fs.readdir(CONFIGS_DIR);
  const jsonFiles = files.filter((f) => f.endsWith(".json"));

  const configs = [];
  for (const f of jsonFiles) {
    try {
      const raw = await fs.readFile(path.join(CONFIGS_DIR, f), "utf-8");
      const cfg = JSON.parse(raw);
      configs.push({ ...cfg, _file: f });
    } catch (_) {
      // 跳过损坏的配置文件
    }
  }
  return configs;
}

ipcMain.handle("list-configs", async () => {
  try {
    const configs = await readAllConfigs();
    return { success: true, data: configs };
  } catch (e) {
    return { success: false, error: `列出配置失败: ${e.message}` };
  }
});

/** delete-config: 删除指定配置 */
ipcMain.handle("delete-config", async (_event, name) => {
  try {
    if (!name) return { success: false, error: "请指定要删除的配置名称" };
    const fname = safeName(name);
    const filePath = path.join(CONFIGS_DIR, `${fname}.json`);
    await fs.unlink(filePath);
    await appendLog(`删除配置: ${fname}`);
    broadcastToRenderers("configs-changed");
    return { success: true };
  } catch (e) {
    if (e.code === "ENOENT") {
      return { success: false, error: `配置 "${name}" 不存在` };
    }
    return { success: false, error: `删除配置失败: ${e.message}` };
  }
});

/** apply-config: 合并 IP + DNS 为一次 sudo 调用（减少密码提示次数，支持 Touch ID） */
async function applyConfigByName(name) {
  try {
    if (!name) return { success: false, error: "请指定要应用的配置名称" };

    const fname = safeName(name);
    const filePath = path.join(CONFIGS_DIR, `${fname}.json`);
    let config;
    try {
      const raw = await fs.readFile(filePath, "utf-8");
      config = JSON.parse(raw);
    } catch (_) {
      return { success: false, error: `配置 "${name}" 不存在或已损坏` };
    }

    const iface = config.interface;
    const netName = config.serviceName || await getServiceName(iface);
    if (!netName) {
      return {
        success: false,
        error: `无法找到网卡 "${iface}" 对应的网络服务名。\n\n` +
               `请执行以下命令查看可用服务:\n` +
               `  networksetup -listallhardwareports\n\n` +
               `或在配置文件中手动添加 "serviceName" 字段指定服务名（如 "Wi-Fi"、"Ethernet"）。`,
      };
    }

    // 网关为空时，保留该网卡自身的 Router（每网卡各自网关），避免 -setmanual 传空串清空网关
    // 注意：读的是"目标服务自身的网关"(networksetup -getinfo 的 Router)，而不是系统默认路由
    // (netstat default)。后者在多网卡/多默认路由时会读到别的网卡的网关，导致写错网关"掉网关"。
    let effectiveGateway = config.gateway || "";
    if (!effectiveGateway) {
      const curGw = (await getServiceRouter(netName)) || (await getCurrentGateway());
      if (curGw) effectiveGateway = curGw;
    }

    // 合并 IP 设置 + DNS 设置为一次 sudo 调用，减少密码提示 / 触发 Touch ID
    let commands = `networksetup -setmanual "${netName}" "${config.ip}" "${config.netmask}" "${effectiveGateway}"`;
    if (config.dns && config.dns.length > 0) {
      const dnsArgs = config.dns.map((d) => `"${d}"`).join(" ");
      commands += ` && networksetup -setdnsservers "${netName}" ${dnsArgs}`;
    } else {
      commands += ` && networksetup -setdnsservers "${netName}" Empty`;
    }

    await sudoExec(commands);
    await appendLog(`设置静态IP: ${netName}(${iface}) → ${config.ip}/${config.netmask} gw=${config.gateway}`);

    return { success: true, data: { interface: iface, message: "配置已应用" } };
  } catch (e) {
    await appendLog(`应用配置失败: ${e.message}`);
    return { success: false, error: `应用配置失败: ${e.message}` };
  }
}

ipcMain.handle("apply-config", async (_event, name) => applyConfigByName(name));

/** apply-dhcp: 合并 DHCP + DNS 为一次 sudo 调用 */
async function switchToDHCP(iface) {
  try {
    if (!iface) return { success: false, error: "请指定网卡名称" };

    const netName = await getServiceName(iface);
    if (!netName) {
      return { success: false, error: `无法找到网卡 "${iface}" 对应的网络服务名` };
    }

    // 合并 DHCP 切换 + DNS 清空为一次 sudo 调用
    const command = `networksetup -setdhcp "${netName}" && networksetup -setdnsservers "${netName}" Empty`;
    await sudoExec(command);
    await appendLog(`切换DHCP: ${netName}(${iface})`);

    return { success: true, data: { interface: iface, message: "已切换为 DHCP" } };
  } catch (e) {
    await appendLog(`切换DHCP失败: ${e.message}`);
    return { success: false, error: `切换 DHCP 失败: ${e.message}` };
  }
}

ipcMain.handle("apply-dhcp", async (_event, iface) => switchToDHCP(iface));

/** get-log: 读取操作日志（最近 500 行） */
ipcMain.handle("get-log", async () => {
  try {
    let raw = "";
    try {
      raw = await fs.readFile(LOG_FILE, "utf-8");
    } catch (_) {
      return { success: true, data: "" };
    }
    const lines = raw.trim().split("\n");
    const recent = lines.slice(-500).join("\n");
    return { success: true, data: recent };
  } catch (e) {
    return { success: false, error: `读取日志失败: ${e.message}` };
  }
});

// ──────────────────────────────────────────────
// 辅助函数
// ──────────────────────────────────────────────

/**
 * 硬件设备名 → 网络服务名 映射
 * 例: en0 → "Wi-Fi", en6 → "USB 10/100/1000 LAN"
 * networksetup 命令需要服务名，不是 BSD 设备名
 *
 * 方法1 (首选): networksetup -listallhardwareports
 * 方法2 (回退): networksetup -listnetworkserviceorder
 */
async function getServiceName(deviceName) {
  // 方法1: listallhardwareports
  try {
    const raw = await execPromise("networksetup", ["-listallhardwareports"]);
    const blocks = raw.split(/\n\n+/);
    for (const block of blocks) {
      const portMatch = block.match(/^Hardware Port:\s*(.+)$/m);
      const devMatch = block.match(/^Device:\s*(.+)$/m);
      if (portMatch && devMatch && devMatch[1] === deviceName) {
        const serviceName = portMatch[1];
        // 防御：确保返回的是服务名而非设备名
        if (!/^en\d+$/.test(serviceName)) {
          return serviceName;
        }
      }
    }
  } catch (_) {
    // 方法1失败，尝试方法2
  }

  // 方法2: listnetworkserviceorder (解析 "Hardware Port: XXX, Device: en0" 格式)
  try {
    const raw = await execPromise("networksetup", ["-listnetworkserviceorder"]);
    const lines = raw.split("\n");
    for (let i = 0; i < lines.length; i++) {
      const portMatch = lines[i].match(/^\(\d+\)\s+(.+)$/);
      if (portMatch) {
        const serviceName = portMatch[1];
        // 获取该服务的硬件端口信息
        const fullDesc = lines.slice(i, i + 3).join(" ");
        const devMatch = fullDesc.match(/Device:\s*(\S+)/);
        if (devMatch && devMatch[1] === deviceName) {
          return serviceName;
        }
      }
    }
  } catch (_) {
    // 方法2也失败
  }

  return null;
}

/** 十六进制掩码转点分十进制 */
function hexToNetmask(hex) {
  const n = parseInt(hex, 16);
  return [(n >>> 24) & 0xff, (n >>> 16) & 0xff, (n >>> 8) & 0xff, n & 0xff].join(".");
}

/** 读取当前默认网关（第一跳），失败返回 null */
async function getCurrentGateway() {
  try {
    const netstatRaw = await execPromise("netstat", ["-rn", "-f", "inet"]);
    const gwMatch = netstatRaw.match(/^default\s+(\d+\.\d+\.\d+\.\d+)/m);
    return gwMatch ? gwMatch[1] : null;
  } catch (_) {
    return null;
  }
}

/**
 * 读取指定网络服务（如 "Wi-Fi"）自身的 Router —— 每网卡各自当前网关，跨网卡准确。
 * 用于 apply-config 时网关为空的情况下保留该网卡的网关，避免清空/写错。
 * 相比 getCurrentGateway()(读取系统默认路由)，多网卡场景下不会错读到别的网卡的网关。
 */
async function getServiceRouter(serviceName) {
  if (!serviceName || typeof serviceName !== "string") return null;
  try {
    const raw = await execPromise("networksetup", ["-getinfo", serviceName]);
    const m = raw.match(/^Router:\s*(\d+\.\d+\.\d+\.\d+)/m);
    return m ? m[1] : null;
  } catch (_) {
    return null;
  }
}

// ──────────────────────────────────────────────
// 菜单栏 Tray（常驻角标）
// ──────────────────────────────────────────────

function setupTray() {
  const icon = nativeImage.createFromPath(path.join(__dirname, "assets", "trayTemplate.png"));
  if (icon.isEmpty()) {
    console.error("加载托盘图标失败: assets/trayTemplate.png");
    return;
  }
  // 模板图标：自动适配浅色/深色菜单栏
  icon.setTemplateImage(true);
  tray = new Tray(icon);
  tray.setToolTip("IPHelper · 点击选择要切换的网络配置");
  tray.on("click", openTrayMenu);
  tray.on("right-click", openTrayMenu);
}

/** 每次点击角标都重新读取配置，保证菜单始终是最新的 */
async function openTrayMenu() {
  if (!tray) return;

  let configs = [];
  let ifaces = [];
  try { configs = await readAllConfigs(); } catch (_) {}
  try { ifaces = await fetchInterfaces(); } catch (_) {}

  const template = [];

  template.push({ label: "IPHelper", enabled: false });
  if (configs.length === 0) {
    template.push({ label: "（暂无已保存配置）", enabled: false });
  } else {
    for (const cfg of configs) {
      const tag = cfg.mode === "dhcp" ? "DHCP" : "静态";
      template.push({
        label: `${cfg.name}（${tag}）`,
        click: () => quickApplyConfig(cfg.name),
      });
    }
  }

  template.push({ type: "separator" });
  template.push({ label: "保存当前配置…", click: openSaveDialog });
  if (ifaces.length > 0) {
    template.push({
      label: "恢复 DHCP",
      submenu: ifaces.map((i) => ({
        label: `${i.displayName}（${i.name}）`,
        click: () => quickSwitchDHCP(i.name),
      })),
    });
  } else {
    template.push({ label: "恢复 DHCP（未找到网卡）", enabled: false });
  }

  template.push({ type: "separator" });
  template.push({ label: "打开完整界面", click: showMainWindow });
  template.push({
    label: "开机自启动",
    type: "checkbox",
    checked: isLaunchAtLoginEnabled(),
    click: (item) => setLaunchAtLogin(item.checked),
  });
  template.push({ type: "separator" });
  template.push({ label: "退出 IPHelper", click: () => app.quit() });

  tray.popUpContextMenu(Menu.buildFromTemplate(template));
}

/** 角标一键应用配置 */
function quickApplyConfig(name) {
  applyConfigByName(name).then((res) => {
    if (res && res.success) {
      notify("IPHelper", `已应用配置「${name}」`);
      if (tray) tray.setToolTip(`IPHelper · 当前：${name}`);
      broadcastToRenderers("network-changed");
      return;
    }
    const msg = (res && res.error) || "未知错误";
    if (isUserCanceled(msg)) return; // 用户在授权框点了取消，不打扰
    dialog.showMessageBox({
      type: "warning",
      title: "IPHelper",
      message: `未能应用配置「${name}」`,
      detail: msg,
      buttons: ["好"],
    });
  });
}

/** 角标一键恢复 DHCP */
function quickSwitchDHCP(iface) {
  switchToDHCP(iface).then((res) => {
    if (res && res.success) {
      notify("IPHelper", `${iface} 已切换为 DHCP`);
      if (tray) tray.setToolTip("IPHelper");
      broadcastToRenderers("network-changed");
      return;
    }
    const msg = (res && res.error) || "未知错误";
    if (isUserCanceled(msg)) return;
    dialog.showMessageBox({
      type: "warning",
      title: "IPHelper",
      message: "切换 DHCP 失败",
      detail: msg,
      buttons: ["好"],
    });
  });
}

// ──────────────────────────────────────────────
// 保存当前配置弹窗
// ──────────────────────────────────────────────

function openSaveDialog() {
  if (saveDlg && !saveDlg.isDestroyed()) {
    saveDlg.show();
    saveDlg.focus();
    return;
  }
  saveDlg = new BrowserWindow({
    width: 460,
    height: 560,
    resizable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    title: "保存当前配置",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
    // macOS 风格
    titleBarStyle: "hiddenInset",
    trafficLightPosition: { x: 12, y: 12 },
  });
  saveDlg.setMenuBarVisibility(false);
  saveDlg.loadFile(path.join(__dirname, "save.html"));
  saveDlg.on("closed", () => {
    saveDlg = null;
  });
}

// ──────────────────────────────────────────────
// 登录自启动
// ──────────────────────────────────────────────

function isLaunchAtLoginEnabled() {
  try {
    return app.getLoginItemSettings().openAtLogin;
  } catch (_) {
    return false;
  }
}

function setLaunchAtLogin(enable) {
  try {
    const opts = { openAtLogin: enable, openAsHidden: true };
    if (!app.isPackaged) {
      // 开发模式下登录项需显式带上启动参数，否则会启动成裸 Electron
      opts.args = [app.getAppPath(), "--launch-at-login"];
    }
    app.setLoginItemSettings(opts);
  } catch (_) {}
}

// ──────────────────────────────────────────────
// 主界面窗口
// ──────────────────────────────────────────────

const WINDOW_OPTS = {
  width: 800,
  height: 700,
  minWidth: 600,
  minHeight: 500,
  title: "IPHelper - 网络切换工具",
  webPreferences: {
    preload: path.join(__dirname, "preload.js"),
    contextIsolation: true,
    nodeIntegration: false,
    sandbox: false,
  },
  // macOS 风格
  titleBarStyle: "hiddenInset",
  trafficLightPosition: { x: 12, y: 12 },
};

function showMainWindow() {
  let win = mainWindow && !mainWindow.isDestroyed() ? mainWindow : null;
  if (!win) {
    win = new BrowserWindow(WINDOW_OPTS);
    mainWindow = win;
    win.loadFile(path.join(__dirname, "index.html"));

    // 关闭主界面时只是隐藏（保留在菜单栏），真正退出时才销毁
    win.on("close", (e) => {
      if (!quitting) {
        e.preventDefault();
        win.hide();
      }
    });
    win.on("closed", () => {
      if (mainWindow === win) mainWindow = null;
    });

    // 开发时自动打开 DevTools
    if (process.argv.includes("--dev")) {
      win.webContents.openDevTools({ mode: "detach" });
    }
  }
  if (win.isMinimized()) win.restore();
  win.show();
  win.focus();
  return win;
}

// ──────────────────────────────────────────────
// 生命周期
// ──────────────────────────────────────────────

// 菜单栏工具通常为单实例：二次启动时直接唤出主界面
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.whenReady().then(async () => {
    initPaths();
    await ensureConfigsDir();

    // 隐藏 Dock 图标（打包后由 LSUIElement 保证，这里兼容开发模式）
    if (process.platform === "darwin" && !process.argv.includes("--show-dock")) {
      try {
        app.dock.hide();
      } catch (_) {}
    }

    setupTray();

    // 开发模式默认打开主界面便于调试；打包后仅菜单栏常驻
    if (!app.isPackaged) {
      showMainWindow();
    } else if (process.argv.includes("--open-window")) {
      showMainWindow();
    }
  });

  app.on("second-instance", () => showMainWindow());
  app.on("before-quit", () => {
    quitting = true;
  });
}

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
