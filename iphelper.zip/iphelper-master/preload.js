"use strict";

const { contextBridge, ipcRenderer } = require("electron");

/** 订阅主进程广播（返回取消订阅函数） */
function subscribe(channel, callback) {
  const listener = (_event, ...args) => callback(...args);
  ipcRenderer.on(channel, listener);
  return () => ipcRenderer.removeListener(channel, listener);
}

contextBridge.exposeInMainWorld("iphelper", {
  /** 获取物理网卡列表 */
  getInterfaces: () => ipcRenderer.invoke("get-interfaces"),

  /** 抓取指定网卡的当前配置 */
  getCurrentConfig: (iface) => ipcRenderer.invoke("get-current-config", iface),

  /** 保存配置 */
  saveConfig: (config) => ipcRenderer.invoke("save-config", config),

  /** 列出所有已保存配置 */
  listConfigs: () => ipcRenderer.invoke("list-configs"),

  /** 删除配置 */
  deleteConfig: (name) => ipcRenderer.invoke("delete-config", name),

  /** 应用静态配置 */
  applyConfig: (name) => ipcRenderer.invoke("apply-config", name),

  /** 恢复 DHCP */
  applyDHCP: (iface) => ipcRenderer.invoke("apply-dhcp", iface),

  /** 读取指定网卡的 DNS */
  getDNS: (iface) => ipcRenderer.invoke("get-dns", iface),

  /** 写入指定网卡的 DNS（servers 空数组 = 恢复自动） */
  setDNS: (iface, servers) => ipcRenderer.invoke("set-dns", iface, servers),

  /** 读取操作日志 */
  getLog: () => ipcRenderer.invoke("get-log"),

  /** 关闭当前窗口（供弹窗/页面使用） */
  closeSelf: () => ipcRenderer.send("close-current-window"),

  /** 配置增删改后触发（主界面据此刷新） */
  onConfigsChanged: (callback) => subscribe("configs-changed", callback),

  /** 网络被切换后触发 */
  onNetworkChanged: (callback) => subscribe("network-changed", callback),
});
